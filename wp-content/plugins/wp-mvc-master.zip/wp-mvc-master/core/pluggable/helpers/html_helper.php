<?php

class HtmlHelper extends MvcHtmlHelper {

}

?>