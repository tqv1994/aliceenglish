<div>
    <?php echo $this->html->speaker_link($object); ?>
</div>