<?php

function themify_do_demo_import() {
$term = array (
  'term_id' => 21,
  'name' => 'Main Navigation',
  'slug' => 'main-navigation',
  'term_group' => 0,
  'taxonomy' => 'nav_menu',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 2,
  'name' => 'simple',
  'slug' => 'simple',
  'term_group' => 0,
  'taxonomy' => 'product_type',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 16,
  'name' => 'Segway',
  'slug' => 'segway',
  'term_group' => 0,
  'taxonomy' => 'product_cat',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 17,
  'name' => 'Hub',
  'slug' => 'hub',
  'term_group' => 0,
  'taxonomy' => 'product_cat',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 18,
  'name' => 'Smartwatch',
  'slug' => 'smartwatch',
  'term_group' => 0,
  'taxonomy' => 'product_cat',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 19,
  'name' => 'Audio',
  'slug' => 'audio',
  'term_group' => 0,
  'taxonomy' => 'product_cat',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 20,
  'name' => 'Smartphone',
  'slug' => 'smartphone',
  'term_group' => 0,
  'taxonomy' => 'product_cat',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$post = array (
  'ID' => 128,
  'post_date' => '2021-03-19 03:38:53',
  'post_date_gmt' => '2021-03-19 03:38:53',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><img loading="lazy" width="1380" height="395" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/about.jpg" title="about" alt="about" srcset="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/about.jpg 1380w, https://themify.me/demo/themes/ultra-gadgets/files/2021/03/about-600x172.jpg 600w, https://themify.me/demo/themes/ultra-gadgets/files/2021/03/about-768x220.jpg 768w" sizes="(max-width: 1380px) 100vw, 1380px" />
<h2>About Us</h2> <p>Our vision is to provide the highest quality and the most-up-to-date gadgets available in the market. We believe that technology enhances people\'s lives so we ensure that we make it readily available to everyone - anytime, anywhere. With a vast selection of gadgets and accessories, we will be your one-stop shop for all your technology needs.</p>
<p>Dating back to the year 2000, we operated as a reseller, making newly released gadgets readily available to consumers at limited quantities. We were operating as a team of two with the goal of creating a platform where everyone can stay up to date with the latest technology and gadgets. Over the years, we have made a mark on the industry as the leading gadget provider.</p>
<p>We feature a vast collection of the latest gadgets and technologies, with new discounts and deals daily. Watch product reviews and stay up to date to new releases and latest tech news. You can also discover our products in VR, AR and 3D to help you in your purchasing decision. Make sure to get notified for product releases, product reminders or sale reminders.</p>
<p>The best way to discover new products is through Gadgets. With a team of researchers, we ensure that we provide only the best selection of gadgets. We present the products the right way, to be as transparent and as informative about the product as possible. We specifically curate all the gadgets hand-picked by our team of technophiles.</p>
<h3> Why Choose Us</h3> <p>We are your one-stop shop for all your technology needs, and your up-to-date tech news. With guaranteed low prices and daily support available, you can be assured that you will be making the best purchase decision.</p>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/free-61x59.png" width="61" height="59" title="Free Shipping" alt="For orders over $200"> <h3> Free Shipping </h3> For orders over $200
<img loading="lazy" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/free-return-61x59.png" width="61" height="59" title="Free Returns" alt="30-day refund policy"> <h3> Free Returns </h3> 30-day refund policy
<img loading="lazy" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/low-price-61x59.png" width="61" height="59" title="Low Price " alt="Guaranteed Low Prices"> <h3> Low Price </h3> Guaranteed Low Prices
<img loading="lazy" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/support-61x59.png" width="61" height="59" title="Support" alt="Daily 9AM to 8PM EST"> <h3> Support </h3> Daily 9AM to 8PM EST
<h2>Our Headquarter</h2>
<h4>416-123-8899</h4> <p>123 Main Street Toronto, ON</p>
<a href="https://themify.me/" > Contact </a>
<p>Mon-Fri: 11am - 8pm<br />Sat - Sun: 11am - 6pm</p>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/hq-690x511.jpg" width="690" height="511" title="hq" alt="hq" srcset="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/hq.jpg 690w, https://themify.me/demo/themes/ultra-gadgets/files/2021/03/hq-600x444.jpg 600w" sizes="(max-width: 690px) 100vw, 690px" />
<h2>Shop Categories</h2>
<a href="https://themify.me/demo/themes/ultra-gadgets/product/xiaomi-poco-m3/" > <img loading="lazy" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/02/xiomipoco-74x112.png" width="74" height="112" title="POCO M3 " alt="MI"> </a> <h3> <a href="https://themify.me/demo/themes/ultra-gadgets/product/xiaomi-poco-m3/" > POCO M3 </a> </h3> MI
<a href="https://themify.me/demo/themes/ultra-gadgets/product/google-chrome-cast/" > <img loading="lazy" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/02/chromecast-74x112.png" width="74" height="112" title="Chromecast" alt="Google"> </a> <h3> <a href="https://themify.me/demo/themes/ultra-gadgets/product/google-chrome-cast/" > Chromecast </a> </h3> Google
<a href="https://themify.me/demo/themes/ultra-gadgets/product/redmi-powerbank/" > <img loading="lazy" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/02/redmi-powerbank-74x112.png" width="74" height="112" title="Powerbank" alt="Redmi"> </a> <h3> <a href="https://themify.me/demo/themes/ultra-gadgets/product/redmi-powerbank/" > Powerbank </a> </h3> Redmi
<a href="https://themify.me/demo/themes/ultra-gadgets/product/samsung-galaxy-sport-gear/" > <img loading="lazy" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/02/samsung-smartwatch-74x112.png" width="74" height="112" title="Smartwatch" alt="Samsung"> </a> <h3> <a href="https://themify.me/demo/themes/ultra-gadgets/product/samsung-galaxy-sport-gear/" > Smartwatch </a> </h3> Samsung
<a href="https://themify.me/demo/themes/ultra-gadgets/product/airpods/" > <img loading="lazy" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/02/airpods-74x112.png" width="74" height="112" title="Airpods" alt="Apple"> </a> <h3> <a href="https://themify.me/demo/themes/ultra-gadgets/product/airpods/" > Airpods </a> </h3> Apple
<img loading="lazy" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/02/more-74x112.png" width="74" height="112" title="More" alt="More"> <h3> More </h3><!--/themify_builder_static-->',
  'post_title' => 'About',
  'post_excerpt' => '',
  'post_name' => 'about',
  'post_modified' => '2021-03-29 00:26:04',
  'post_modified_gmt' => '2021-03-29 00:26:04',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-gadgets/?page_id=128',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'section_scrolling_mobile' => 'on',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"uuyt184\\",\\"cols\\":[{\\"element_id\\":\\"zn2e185\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"hgip883\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":\\"1\\",\\"appearance_image\\":\\"rounded\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/03\\\\/about.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\"}},{\\"element_id\\":\\"pqc7373\\",\\"cols\\":[{\\"element_id\\":\\"dehx374\\",\\"grid_class\\":\\"col4-1\\"},{\\"element_id\\":\\"0gsi374\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"e4sg348\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>About Us<\\\\/h2>\\\\n<p>Our vision is to provide the highest quality and the most-up-to-date gadgets available in the market. We believe that technology enhances people\\\'s lives so we ensure that we make it readily available to everyone - anytime, anywhere. With a vast selection of gadgets and accessories, we will be your one-stop shop for all your technology needs.<\\\\/p>\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"30\\",\\"margin_opp_bottom\\":false,\\"margin_top\\":\\"50\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\"}}]},{\\"element_id\\":\\"4cl0304\\",\\"grid_class\\":\\"col4-1\\"}]},{\\"element_id\\":\\"tu98684\\",\\"cols\\":[{\\"element_id\\":\\"jjjk687\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"7jln400\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>Dating back to the year 2000, we operated as a reseller, making newly released gadgets readily available to consumers at limited quantities. We were operating as a team of two with the goal of creating a platform where everyone can stay up to date with the latest technology and gadgets. Over the years, we have made a mark on the industry as the leading gadget provider.<\\\\/p>\\"}}]},{\\"element_id\\":\\"opci687\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"p23w933\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>We feature a vast collection of the latest gadgets and technologies, with new discounts and deals daily. Watch product reviews and stay up to date to new releases and latest tech news. You can also discover our products in VR, AR and 3D to help you in your purchasing decision. Make sure to get notified for product releases, product reminders or sale reminders.<\\\\/p>\\"}}]},{\\"element_id\\":\\"rueo687\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"gqp8299\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>The best way to discover new products is through Gadgets. With a team of researchers, we ensure that we provide only the best selection of gadgets. We present the products the right way, to be as transparent and as informative about the product as possible. We specifically curate all the gadgets hand-picked by our team of technophiles.<\\\\/p>\\"}}]}]}]}],\\"styling\\":{\\"padding_top\\":\\"4\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"4\\",\\"padding_opp_bottom\\":\\"1\\"}},{\\"element_id\\":\\"aywr787\\",\\"cols\\":[{\\"element_id\\":\\"qc1g788\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"xfba76\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3> Why Choose Us<\\\\/h3>\\\\n<p>We are your one-stop shop for all your technology needs, and your up-to-date tech news. With guaranteed low prices and daily support available, you can be assured that you will be making the best purchase decision.<\\\\/p>\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"font_size_unit\\":\\"px\\",\\"font_size\\":\\"26\\",\\"padding_right\\":\\"80\\",\\"padding_left\\":\\"80\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false,\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_right\\":\\"0\\",\\"padding_left_unit\\":\\"px\\",\\"padding_left\\":\\"0\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_opp_bottom\\":false,\\"padding_top_unit\\":\\"px\\"}}}]}],\\"styling\\":{\\"row_width\\":\\"fullwidth\\",\\"padding_top\\":\\"8\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":12,\\"padding_opp_bottom\\":\\"1\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/03\\\\/banner-about.jpg\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"font_color\\":\\"#ffffff\\",\\"cover_color\\":\\"#000000_0.23\\",\\"cover_color-type\\":\\"color\\"}},{\\"element_id\\":\\"haug975\\",\\"cols\\":[{\\"element_id\\":\\"mifj980\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"zk6s421\\",\\"cols\\":[{\\"element_id\\":\\"fexp422\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"k1kw24\\",\\"mod_settings\\":{\\"caption_image\\":\\"For orders over $200\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Free Shipping\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/03\\\\/free.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"height_image\\":\\"59\\",\\"width_image\\":\\"61\\"}}]},{\\"element_id\\":\\"mr07422\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"35ns121\\",\\"mod_settings\\":{\\"caption_image\\":\\"30-day refund policy\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Free Returns\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/03\\\\/free-return.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"height_image\\":\\"59\\",\\"width_image\\":\\"61\\"}}]},{\\"element_id\\":\\"h05n422\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"km9h735\\",\\"mod_settings\\":{\\"caption_image\\":\\"Guaranteed Low Prices\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Low Price \\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/03\\\\/low-price.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"height_image\\":\\"59\\",\\"width_image\\":\\"61\\"}}]},{\\"element_id\\":\\"r99q423\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"55hz179\\",\\"mod_settings\\":{\\"caption_image\\":\\"Daily 9AM to 8PM EST\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Support\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/03\\\\/support.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"height_image\\":\\"59\\",\\"width_image\\":\\"61\\"}}]}],\\"gutter\\":\\"gutter-none\\",\\"styling\\":{\\"background_color\\":\\"#ffffff\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_opp_left\\":\\"1\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_right\\":\\"5\\",\\"padding_left\\":\\"5\\",\\"padding_bottom\\":\\"5\\",\\"padding_top\\":4,\\"b_ra_opp_left\\":false,\\"b_ra_right\\":\\"10\\",\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"10\\"}}]}],\\"styling\\":{\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":\\"1\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"%\\",\\"margin-top\\":\\"-7\\"}},{\\"element_id\\":\\"ma0l967\\",\\"cols\\":[{\\"element_id\\":\\"wkh7968\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"1eou84\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Our Headquarter<\\\\/h2>\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"30\\",\\"margin_opp_bottom\\":false}},{\\"element_id\\":\\"khvy32\\",\\"cols\\":[{\\"element_id\\":\\"2y8q32\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"nvw5125\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>416-123-8899<\\\\/h4>\\\\n<p>123 Main Street Toronto, ON<\\\\/p>\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"lr8o63\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Contact\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"blue\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"circle\\",\\"buttons_size\\":\\"normal\\"}}]},{\\"element_id\\":\\"e9f133\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"9gy0749\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>Mon-Fri: 11am - 8pm<br \\\\/>Sat - Sun: 11am - 6pm<\\\\/p>\\"}}]}]}]},{\\"element_id\\":\\"o3dn136\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"3k2k781\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"511\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"690\\",\\"appearance_image\\":\\"rounded\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/03\\\\/hq.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\"},{\\"element_id\\":\\"bxi6718\\",\\"cols\\":[{\\"element_id\\":\\"xha2719\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"36dp549\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Shop Categories<\\\\/h2>\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"30\\",\\"margin_opp_bottom\\":false}},{\\"element_id\\":\\"ghoe775\\",\\"cols\\":[{\\"element_id\\":\\"7hna161\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"gjf0162\\",\\"mod_settings\\":{\\"caption_image\\":\\"MI\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"POCO M3 \\",\\"height_image\\":\\"112\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"74\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/02\\\\/xiomipoco.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/product\\\\/xiaomi-poco-m3\\\\/\\"}}],\\"styling\\":{\\"margin-top_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false,\\"padding_bottom\\":\\"15\\",\\"padding_top\\":\\"20\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color-type\\":\\"color\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"b_c_h\\":\\"#f8f8f8\\",\\"b_p_h\\":\\"50,50\\",\\"b_a_h\\":\\"scroll\\",\\"b_r_h\\":\\"repeat\\",\\"b_g_h-circle-radial\\":false,\\"b_t_h\\":\\"image\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"xfke775\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"enc4775\\",\\"mod_settings\\":{\\"caption_image\\":\\"Google\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Chromecast\\",\\"height_image\\":\\"112\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"74\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/02\\\\/chromecast.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":\\"1\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/product\\\\/google-chrome-cast\\\\/\\"}}],\\"styling\\":{\\"margin-top_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"20\\",\\"padding_top\\":\\"20\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color-type\\":\\"color\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"b_c_h\\":\\"#f8f8f8\\",\\"b_p_h\\":\\"50,50\\",\\"b_a_h\\":\\"scroll\\",\\"b_r_h\\":\\"repeat\\",\\"b_g_h-circle-radial\\":false,\\"b_t_h\\":\\"image\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"7yzw950\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"s8sq951\\",\\"mod_settings\\":{\\"caption_image\\":\\"Redmi\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Powerbank\\",\\"height_image\\":\\"112\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"74\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/02\\\\/redmi-powerbank.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/product\\\\/redmi-powerbank\\\\/\\"}}],\\"styling\\":{\\"margin-top_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"20\\",\\"padding_top\\":\\"20\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color-type\\":\\"color\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"b_c_h\\":\\"#f8f8f8\\",\\"b_p_h\\":\\"50,50\\",\\"b_a_h\\":\\"scroll\\",\\"b_r_h\\":\\"repeat\\",\\"b_g_h-circle-radial\\":false,\\"b_t_h\\":\\"image\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"q4b3734\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"2v25734\\",\\"mod_settings\\":{\\"caption_image\\":\\"Samsung\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Smartwatch\\",\\"height_image\\":\\"112\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"74\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/02\\\\/samsung-smartwatch.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/product\\\\/samsung-galaxy-sport-gear\\\\/\\"}}],\\"styling\\":{\\"margin-top_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"20\\",\\"padding_top\\":\\"20\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color-type\\":\\"color\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"b_c_h\\":\\"#f8f8f8\\",\\"b_p_h\\":\\"50,50\\",\\"b_a_h\\":\\"scroll\\",\\"b_r_h\\":\\"repeat\\",\\"b_g_h-circle-radial\\":false,\\"b_t_h\\":\\"image\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"ka2r694\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"507j695\\",\\"mod_settings\\":{\\"caption_image\\":\\"Apple\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Airpods\\",\\"height_image\\":\\"112\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"74\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/02\\\\/airpods.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/product\\\\/airpods\\\\/\\"}}],\\"styling\\":{\\"margin-top_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"20\\",\\"padding_top\\":\\"20\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color-type\\":\\"color\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"b_c_h\\":\\"#f8f8f8\\",\\"b_p_h\\":\\"50,50\\",\\"b_a_h\\":\\"scroll\\",\\"b_r_h\\":\\"repeat\\",\\"b_g_h-circle-radial\\":false,\\"b_t_h\\":\\"image\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"2xgl807\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"te0k807\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"More\\",\\"height_image\\":\\"112\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"74\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/02\\\\/more.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\"}}],\\"styling\\":{\\"margin-top_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"20\\",\\"padding_top\\":\\"20\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color-type\\":\\"color\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"b_c_h\\":\\"#f8f8f8\\",\\"b_p_h\\":\\"50,50\\",\\"b_a_h\\":\\"scroll\\",\\"b_r_h\\":\\"repeat\\",\\"b_g_h-circle-radial\\":false,\\"b_t_h\\":\\"image\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}]}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"4\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top\\":7,\\"text_align\\":\\"center\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 175,
  'post_date' => '2021-03-20 10:39:44',
  'post_date_gmt' => '2021-03-20 10:39:44',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><img loading="lazy" width="1200" height="395" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/contact-banner-no-corner.jpg" title="contact-banner-no-corner" alt="contact-banner-no-corner" srcset="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/contact-banner-no-corner.jpg 1200w, https://themify.me/demo/themes/ultra-gadgets/files/2021/03/contact-banner-no-corner-600x198.jpg 600w, https://themify.me/demo/themes/ultra-gadgets/files/2021/03/contact-banner-no-corner-768x253.jpg 768w" sizes="(max-width: 1200px) 100vw, 1200px" />
<h2>Contact Us</h2> <p>For quickest answers to common questions, refer to our FAQ below. </p> <p>Couldn\'t find the answer your looking for? Contact us at 1-800-000-000 or email us at info@gadgets.com and we\'ll make sure you get the information you need.</p>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/customer-support-61x59.png" width="61" height="59" title="Customer Support" alt="Available Monday-Friday between 9am-8pm EST"> <h3> Customer Support </h3> Available Monday-Friday between 9am-8pm EST
<a href="https://themify.me/" > Get Support </a>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/partnership-61x59.png" width="61" height="59" title="Partnership Info" alt="We are always seeking for partnership opportunities."> <h3> Partnership Info </h3> We are always seeking for partnership opportunities.
<a href="https://themify.me/" > Partner With Us </a>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/return-policy-61x59.png" width="61" height="59" title="Shipping &amp; Return Policy" alt="Fast, Free Shipping and Easy Returns."> <h3> Shipping & Return Policy </h3> Fast, Free Shipping and Easy Returns.
<a href="https://themify.me/" > Return Policy </a>
<h2>Our Stores</h2>
<h3>Store Electronic Center</h3>
<i><svg aria-hidden="true"><use href="#tf-ti-location-pin"></use></svg></i> 2406 Brook St, Newcombville Nova Scotia, Canada
<i><svg aria-hidden="true"><use href="#tf-ti-mobile"></use></svg></i> (514)849-123
<i><svg aria-hidden="true"><use href="#tf-ti-time"></use></svg></i> Mon-Fri: 11am - 8pm <br/>Sat & Sun: 11am - 6pm
<a href="https://themify.me"> <i><svg aria-hidden="true"><use href="#tf-ti-arrow-right"></use></svg></i> Get Direction </a>
<h3>Store Electronic Center</h3>
<i><svg aria-hidden="true"><use href="#tf-ti-location-pin"></use></svg></i> 2406 Brook St, Newcombville Nova Scotia, Canada
<i><svg aria-hidden="true"><use href="#tf-ti-mobile"></use></svg></i> (514)849-123
<i><svg aria-hidden="true"><use href="#tf-ti-time"></use></svg></i> Mon-Fri: 11am - 8pm <br/>Sat & Sun: 11am - 6pm
<a href="https://themify.me"> <i><svg aria-hidden="true"><use href="#tf-ti-arrow-right"></use></svg></i> Get Direction </a>
<h3>Store Electronic Center</h3>
<i><svg aria-hidden="true"><use href="#tf-ti-location-pin"></use></svg></i> 2406 Brook St, Newcombville Nova Scotia, Canada
<i><svg aria-hidden="true"><use href="#tf-ti-mobile"></use></svg></i> (514)849-123
<i><svg aria-hidden="true"><use href="#tf-ti-time"></use></svg></i> Mon-Fri: 11am - 8pm <br/>Sat & Sun: 11am - 6pm
<a href="https://themify.me"> <i><svg aria-hidden="true"><use href="#tf-ti-arrow-right"></use></svg></i> Get Direction </a>
<h2>FAQs</h2>
<ul><li><h4>How to Buy?</h4><p>You can either Order online or Shop in-store.</p> <p><strong>Order Online</strong></p> <p>Place an order online by selecting the items you wish to purchase and adding them to cart and checkout.</p> <p><strong>Shop In-store</strong></p> <p>Visit any one of our three stores to shop.</p></li><li><h4>How to Checkout?</h4><p>When checking out, ensure that you fill in your complete shipping address and payment details, and place your order. You will receive a confirmation email of your order and a separate email when your items have been shipped.</p></li><li><h4>How to Payment?</h4><p>We accept all major credit cards and debit cards. Other payment method also include Paypal.</p></li><li><h4>How to Cancel Order?</h4><p>You can cancel your order online within 24 hours of placing it.</p> <p>If you created an account online, follow these steps to cancel your order:</p> <ul> <li>Login into My Account</li> <li>Click on Orders and select the order # you wish to cancel</li> <li>Click "Cancel"</li> </ul> <p>If you wish to cancel after 24 hours and we still have\'t shipped your order, please send us an email at orders@gadgets.com.</p></li><li><h4>How to Become Reseller?</h4><p>We have a number of packages available for resellers. Contact us at reselling@gadgets.com to get in touch with one of our agents to provide you with more information, as well as, the terms and conditions.</p></li></ul><!--/themify_builder_static-->',
  'post_title' => 'Contact',
  'post_excerpt' => '',
  'post_name' => 'contact',
  'post_modified' => '2021-03-28 17:39:52',
  'post_modified_gmt' => '2021-03-28 17:39:52',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-gadgets/?page_id=175',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'section_scrolling_mobile' => 'on',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"yt2b820\\",\\"cols\\":[{\\"element_id\\":\\"1jjx821\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"j5t1821\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/03\\\\/contact-banner-no-corner.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"checkbox_i_t_r_c_apply_all\\":\\"1\\",\\"i_t_r_c_opp_left\\":false,\\"i_t_r_c_opp_top\\":false,\\"i_t_r_c_top\\":\\"8\\"}},{\\"element_id\\":\\"cdof824\\",\\"cols\\":[{\\"element_id\\":\\"52je825\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"53va825\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Contact Us<\\\\/h2>\\\\n<p>For quickest answers to common questions, refer to our FAQ below. <\\\\/p>\\\\n<p>Couldn\\\'t find the answer your looking for? Contact us at 1-800-000-000 or email us at info@gadgets.com and we\\\'ll make sure you get the information you need.<\\\\/p>\\",\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false,\\"margin_top\\":\\"50\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_right\\":\\"19\\",\\"padding_left\\":\\"19\\",\\"padding_opp_left\\":\\"1\\",\\"padding_opp_bottom\\":false,\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"%\\",\\"padding_right\\":\\"0\\",\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"0\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom_unit\\":\\"px\\",\\"padding_opp_bottom\\":false,\\"padding_top_unit\\":\\"px\\"},\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_top_unit\\":\\"px\\"}}]}],\\"gutter\\":\\"gutter-none\\"},{\\"element_id\\":\\"4za0826\\",\\"cols\\":[{\\"element_id\\":\\"utgv826\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"zpe3826\\",\\"mod_settings\\":{\\"caption_image\\":\\"Available Monday-Friday between 9am-8pm EST\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Customer Support\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/03\\\\/customer-support.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"height_image\\":\\"59\\",\\"width_image\\":\\"61\\",\\"font_color_type\\":\\"font_color_solid\\",\\"border-type\\":\\"right\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false,\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_right_width\\":\\"0\\",\\"border_right_color\\":\\"#000000_0.00\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"},\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_top_style\\":\\"solid\\",\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_width_unit\\":\\"px\\",\\"checkbox_padding_apply_all\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_top_unit\\":\\"px\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"iizf827\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Get Support\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"blue\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"circle\\",\\"buttons_size\\":\\"normal\\"}}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":\\"1\\",\\"padding_opp_bottom\\":false,\\"padding_top\\":\\"2\\",\\"text_align\\":\\"center\\",\\"border-type\\":\\"right\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"breakpoint_mobile\\":{\\"checkbox_b_ra_apply_all\\":false,\\"b_ra_bottom_unit\\":\\"px\\",\\"b_ra_left_unit\\":\\"px\\",\\"b_ra_left\\":\\"0\\",\\"b_ra_opp_left\\":false,\\"b_ra_right_unit\\":\\"px\\",\\"b_ra_opp_top\\":false,\\"b_ra_top_unit\\":\\"px\\",\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_right_width\\":\\"0\\",\\"border_right_color\\":\\"#000000_0.00\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\",\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"5\\",\\"padding_opp_bottom\\":false,\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"5\\"},\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#000000_0.10\\",\\"border_top_style\\":\\"solid\\",\\"checkbox_b_ra_apply_all\\":false,\\"b_ra_bottom_unit\\":\\"px\\",\\"b_ra_left_unit\\":\\"px\\",\\"b_ra_right_unit\\":\\"px\\",\\"b_ra_top_unit\\":\\"px\\",\\"background_gradient-circle-radial\\":false,\\"background_gradient-gradient-angle\\":\\"180\\",\\"background_gradient-gradient-type\\":\\"linear\\",\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"%\\",\\"padding_right\\":\\"5\\",\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"5\\"}},{\\"element_id\\":\\"098o827\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"z8g8827\\",\\"mod_settings\\":{\\"caption_image\\":\\"We are always seeking for partnership opportunities.\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Partnership Info\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/03\\\\/partnership.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"height_image\\":\\"59\\",\\"width_image\\":\\"61\\",\\"font_color_type\\":\\"font_color_solid\\",\\"border-type\\":\\"right\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false,\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_right_width\\":\\"0\\",\\"border_right_color\\":\\"#000000_0.00\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"},\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_width_unit\\":\\"px\\",\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_top_style\\":\\"solid\\",\\"checkbox_padding_apply_all\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_top_unit\\":\\"px\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"woon828\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Partner With Us\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"blue\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"circle\\",\\"buttons_size\\":\\"normal\\"}}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":\\"1\\",\\"padding_opp_bottom\\":false,\\"padding_top\\":\\"2\\",\\"text_align\\":\\"center\\",\\"border-type\\":\\"right\\",\\"padding_bottom\\":\\"2\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#000000_0.10\\",\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_right_width\\":\\"0\\",\\"border_right_color\\":\\"#000000_0.00\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\",\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"5\\",\\"padding_opp_bottom\\":false,\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"5\\"},\\"checkbox_b_ra_apply_all\\":false,\\"b_ra_bottom_unit\\":\\"px\\",\\"b_ra_left_unit\\":\\"px\\",\\"b_ra_opp_left\\":false,\\"b_ra_right_unit\\":\\"px\\",\\"b_ra_opp_top\\":false,\\"b_ra_top_unit\\":\\"px\\",\\"background_gradient-circle-radial\\":false,\\"background_gradient-gradient-angle\\":\\"180\\",\\"background_gradient-gradient-type\\":\\"linear\\",\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"%\\",\\"padding_right\\":\\"5\\",\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"5\\"}},{\\"element_id\\":\\"0rn3829\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"goe7829\\",\\"mod_settings\\":{\\"caption_image\\":\\"Fast, Free Shipping and Easy Returns.\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Shipping & Return Policy\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/03\\\\/return-policy.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"height_image\\":\\"59\\",\\"width_image\\":\\"61\\",\\"font_color_type\\":\\"font_color_solid\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"m4o7830\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Return Policy\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"blue\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"circle\\",\\"buttons_size\\":\\"normal\\"}}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false,\\"padding_top\\":\\"2\\",\\"text_align\\":\\"center\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"breakpoint_mobile\\":{\\"checkbox_b_ra_apply_all\\":false,\\"b_ra_bottom_unit\\":\\"px\\",\\"b_ra_bottom\\":\\"8\\",\\"b_ra_left_unit\\":\\"px\\",\\"b_ra_left\\":\\"8\\",\\"b_ra_opp_left\\":false,\\"b_ra_right_unit\\":\\"px\\",\\"b_ra_opp_top\\":false,\\"b_ra_top_unit\\":\\"px\\"},\\"checkbox_b_ra_apply_all\\":false,\\"b_ra_bottom_unit\\":\\"px\\",\\"b_ra_left_unit\\":\\"px\\",\\"b_ra_right_unit\\":\\"px\\",\\"b_ra_top_unit\\":\\"px\\",\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"top\\",\\"background_gradient-circle-radial\\":false,\\"background_gradient-gradient-angle\\":\\"180\\",\\"background_gradient-gradient-type\\":\\"linear\\",\\"padding_right\\":\\"5\\",\\"padding_left\\":\\"5\\",\\"padding_bottom\\":\\"2\\"}}],\\"gutter\\":\\"gutter-none\\",\\"styling\\":{\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"zi\\":\\"1\\",\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false,\\"ht_auto_height\\":false,\\"motion_effects\\":{\\"s\\":{\\"val\\":{\\"s_origin\\":\\"50,50\\"}}},\\"cover_gradient-circle-radial\\":false,\\"cover_gradient-gradient-angle\\":\\"180\\",\\"cover_gradient-gradient-type\\":\\"linear\\",\\"cover_color-type\\":\\"color\\",\\"background_gradient-circle-radial\\":false,\\"background_gradient-gradient-angle\\":\\"180\\",\\"background_gradient-gradient-type\\":\\"linear\\",\\"checkbox_margin_apply_all\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_top_unit\\":\\"px\\",\\"checkbox_padding_apply_all\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_b_ra_apply_all\\":false,\\"b_ra_bottom_unit\\":\\"px\\",\\"b_ra_bottom\\":\\"8\\",\\"b_ra_left_unit\\":\\"px\\",\\"b_ra_left\\":\\"8\\",\\"b_ra_right_unit\\":\\"px\\",\\"b_ra_top_unit\\":\\"px\\",\\"background_color\\":\\"#ffffff\\",\\"padding_right_unit\\":\\"px\\",\\"padding_left_unit\\":\\"px\\",\\"padding_bottom\\":\\"3\\",\\"padding_top\\":\\"2\\"}}]}],\\"styling\\":{\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false,\\"padding_top\\":\\"4\\"}},{\\"element_id\\":\\"790m820\\",\\"cols\\":[{\\"element_id\\":\\"0o8q831\\",\\"grid_class\\":\\"col-full\\"}],\\"styling\\":{\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"20\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top\\":\\"20\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/03\\\\/laptops.jpg\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"px\\",\\"margin-top\\":\\"-150\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\"}},{\\"element_id\\":\\"p1ih820\\",\\"cols\\":[{\\"element_id\\":\\"d0xn832\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"57yn832\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Our Stores<\\\\/h2>\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"margin_bottom_unit\\":\\"%\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"3\\",\\"margin_opp_bottom\\":false}},{\\"element_id\\":\\"eg08832\\",\\"cols\\":[{\\"element_id\\":\\"y1ix833\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"infk833\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Store Electronic Center<\\\\/h3>\\",\\"font_size_h3_unit\\":\\"em\\",\\"font_size_h3\\":\\"1.04\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"yte4833\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-location-pin\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"2406 Brook St, Newcombville Nova Scotia, Canada\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"}],\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"checkbox_m_i_apply_all\\":false,\\"m_i_right_unit\\":\\"px\\",\\"m_i_left_unit\\":\\"px\\",\\"m_i_opp_left\\":false,\\"m_i_bottom_unit\\":\\"px\\",\\"m_i_bottom\\":\\"25\\",\\"m_i_opp_bottom\\":false,\\"m_i_top_unit\\":\\"px\\",\\"m_i_top\\":\\"0\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"font_color_icon\\":\\"#198be3\\",\\"checkbox_p_i_apply_all\\":false,\\"p_i_right_unit\\":\\"px\\",\\"p_i_left_unit\\":\\"px\\",\\"p_i_left\\":\\"0\\",\\"p_i_opp_left\\":false,\\"p_i_bottom_unit\\":\\"px\\",\\"p_i_opp_bottom\\":false,\\"p_i_top_unit\\":\\"px\\",\\"m_i_right\\":\\"15\\",\\"p_i_right\\":\\"0\\",\\"f_s_i_unit\\":\\"px\\",\\"f_s_i\\":\\"24\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"z7si834\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-mobile\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"(514)849-123\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"}],\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"checkbox_m_i_apply_all\\":false,\\"m_i_right_unit\\":\\"px\\",\\"m_i_left_unit\\":\\"px\\",\\"m_i_opp_left\\":false,\\"m_i_bottom_unit\\":\\"px\\",\\"m_i_opp_bottom\\":false,\\"m_i_top_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"font_color_icon\\":\\"#198be3\\",\\"m_i_right\\":\\"15\\",\\"checkbox_p_i_apply_all\\":false,\\"p_i_right_unit\\":\\"px\\",\\"p_i_right\\":\\"0\\",\\"p_i_left_unit\\":\\"px\\",\\"p_i_left\\":\\"0\\",\\"p_i_opp_left\\":false,\\"p_i_bottom_unit\\":\\"px\\",\\"p_i_opp_bottom\\":false,\\"p_i_top_unit\\":\\"px\\",\\"f_s_i_unit\\":\\"px\\",\\"f_s_i\\":\\"24\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"do7m834\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-time\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"Mon-Fri: 11am - 8pm <br\\\\/>Sat & Sun: 11am - 6pm\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"}],\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"checkbox_m_i_apply_all\\":false,\\"m_i_right_unit\\":\\"px\\",\\"m_i_left_unit\\":\\"px\\",\\"m_i_opp_left\\":false,\\"m_i_bottom_unit\\":\\"px\\",\\"m_i_opp_bottom\\":false,\\"m_i_top_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"m_i_bottom\\":\\"20\\",\\"font_color_icon\\":\\"#198be3\\",\\"m_i_right\\":\\"15\\",\\"checkbox_p_i_apply_all\\":false,\\"p_i_right_unit\\":\\"px\\",\\"p_i_right\\":\\"0\\",\\"p_i_left_unit\\":\\"px\\",\\"p_i_left\\":\\"0\\",\\"p_i_opp_left\\":false,\\"p_i_bottom_unit\\":\\"px\\",\\"p_i_opp_bottom\\":false,\\"p_i_top_unit\\":\\"px\\",\\"f_s_i_unit\\":\\"px\\",\\"f_s_i\\":\\"24\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"bu2e834\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-arrow-right\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"Get Direction\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"}],\\"icon_arrangement\\":\\"icon_vertical\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"checkbox_m_i_apply_all\\":false,\\"m_i_right_unit\\":\\"px\\",\\"m_i_left_unit\\":\\"px\\",\\"m_i_opp_left\\":false,\\"m_i_bottom_unit\\":\\"px\\",\\"m_i_opp_bottom\\":false,\\"m_i_top_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"icon_position\\":\\"right\\",\\"checkbox_p_i_apply_all\\":false,\\"p_i_right_unit\\":\\"px\\",\\"p_i_left_unit\\":\\"px\\",\\"p_i_opp_left\\":false,\\"p_i_bottom_unit\\":\\"px\\",\\"p_i_opp_bottom\\":false,\\"p_i_top_unit\\":\\"px\\",\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_top_style\\":\\"solid\\",\\"border_top_width\\":\\"1\\",\\"border_top_color\\":\\"#dedede\\",\\"border-type\\":\\"top\\",\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_opp_bottom\\":false,\\"padding_top_unit\\":\\"px\\",\\"padding_top\\":\\"20\\",\\"font_color_icon\\":\\"#198be3\\"}}],\\"styling\\":{\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":\\"1\\",\\"padding_opp_bottom\\":false,\\"padding_top\\":\\"2.5\\",\\"background_color\\":\\"#eef0f4\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_right\\":\\"3\\",\\"padding_left\\":\\"3\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"1.5\\"}},{\\"element_id\\":\\"xjfd835\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"nsxz835\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Store Electronic Center<\\\\/h3>\\",\\"font_size_h3_unit\\":\\"em\\",\\"font_size_h3\\":\\"1.04\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"ymg1835\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-location-pin\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"2406 Brook St, Newcombville Nova Scotia, Canada\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"}],\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"checkbox_m_i_apply_all\\":false,\\"m_i_right_unit\\":\\"px\\",\\"m_i_left_unit\\":\\"px\\",\\"m_i_opp_left\\":false,\\"m_i_bottom_unit\\":\\"px\\",\\"m_i_bottom\\":\\"25\\",\\"m_i_opp_bottom\\":false,\\"m_i_top_unit\\":\\"px\\",\\"m_i_top\\":\\"0\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"font_color_icon\\":\\"#198be3\\",\\"checkbox_p_i_apply_all\\":false,\\"p_i_right_unit\\":\\"px\\",\\"p_i_left_unit\\":\\"px\\",\\"p_i_left\\":\\"0\\",\\"p_i_opp_left\\":false,\\"p_i_bottom_unit\\":\\"px\\",\\"p_i_opp_bottom\\":false,\\"p_i_top_unit\\":\\"px\\",\\"m_i_right\\":\\"15\\",\\"p_i_right\\":\\"0\\",\\"f_s_i_unit\\":\\"px\\",\\"f_s_i\\":\\"24\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"fazk836\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-mobile\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"(514)849-123\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"}],\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"checkbox_m_i_apply_all\\":false,\\"m_i_right_unit\\":\\"px\\",\\"m_i_left_unit\\":\\"px\\",\\"m_i_opp_left\\":false,\\"m_i_bottom_unit\\":\\"px\\",\\"m_i_opp_bottom\\":false,\\"m_i_top_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"font_color_icon\\":\\"#198be3\\",\\"m_i_right\\":\\"15\\",\\"checkbox_p_i_apply_all\\":false,\\"p_i_right_unit\\":\\"px\\",\\"p_i_right\\":\\"0\\",\\"p_i_left_unit\\":\\"px\\",\\"p_i_left\\":\\"0\\",\\"p_i_opp_left\\":false,\\"p_i_bottom_unit\\":\\"px\\",\\"p_i_opp_bottom\\":false,\\"p_i_top_unit\\":\\"px\\",\\"f_s_i_unit\\":\\"px\\",\\"f_s_i\\":\\"24\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"gdao836\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-time\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"Mon-Fri: 11am - 8pm <br\\\\/>Sat & Sun: 11am - 6pm\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"}],\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"checkbox_m_i_apply_all\\":false,\\"m_i_right_unit\\":\\"px\\",\\"m_i_left_unit\\":\\"px\\",\\"m_i_opp_left\\":false,\\"m_i_bottom_unit\\":\\"px\\",\\"m_i_opp_bottom\\":false,\\"m_i_top_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"m_i_bottom\\":\\"20\\",\\"font_color_icon\\":\\"#198be3\\",\\"m_i_right\\":\\"15\\",\\"checkbox_p_i_apply_all\\":false,\\"p_i_right_unit\\":\\"px\\",\\"p_i_right\\":\\"0\\",\\"p_i_left_unit\\":\\"px\\",\\"p_i_left\\":\\"0\\",\\"p_i_opp_left\\":false,\\"p_i_bottom_unit\\":\\"px\\",\\"p_i_opp_bottom\\":false,\\"p_i_top_unit\\":\\"px\\",\\"f_s_i_unit\\":\\"px\\",\\"f_s_i\\":\\"24\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"8wy3899\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-arrow-right\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"Get Direction\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"}],\\"icon_arrangement\\":\\"icon_vertical\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"checkbox_m_i_apply_all\\":false,\\"m_i_right_unit\\":\\"px\\",\\"m_i_left_unit\\":\\"px\\",\\"m_i_opp_left\\":false,\\"m_i_bottom_unit\\":\\"px\\",\\"m_i_opp_bottom\\":false,\\"m_i_top_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"icon_position\\":\\"right\\",\\"checkbox_p_i_apply_all\\":false,\\"p_i_right_unit\\":\\"px\\",\\"p_i_left_unit\\":\\"px\\",\\"p_i_opp_left\\":false,\\"p_i_bottom_unit\\":\\"px\\",\\"p_i_opp_bottom\\":false,\\"p_i_top_unit\\":\\"px\\",\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_top_style\\":\\"solid\\",\\"border_top_width\\":\\"1\\",\\"border_top_color\\":\\"#dedede\\",\\"border-type\\":\\"top\\",\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_opp_bottom\\":false,\\"padding_top_unit\\":\\"px\\",\\"padding_top\\":\\"20\\",\\"font_color_icon\\":\\"#198be3\\"}}],\\"styling\\":{\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":\\"1\\",\\"padding_opp_bottom\\":false,\\"padding_top\\":\\"2.5\\",\\"background_color\\":\\"#eef0f4\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_right\\":\\"3\\",\\"padding_left\\":\\"3\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"1.5\\"}},{\\"element_id\\":\\"kiqc837\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"pq87837\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Store Electronic Center<\\\\/h3>\\",\\"font_size_h3_unit\\":\\"em\\",\\"font_size_h3\\":\\"1.04\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"rrz9837\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-location-pin\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"2406 Brook St, Newcombville Nova Scotia, Canada\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"}],\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"checkbox_m_i_apply_all\\":false,\\"m_i_right_unit\\":\\"px\\",\\"m_i_left_unit\\":\\"px\\",\\"m_i_opp_left\\":false,\\"m_i_bottom_unit\\":\\"px\\",\\"m_i_bottom\\":\\"25\\",\\"m_i_opp_bottom\\":false,\\"m_i_top_unit\\":\\"px\\",\\"m_i_top\\":\\"0\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"font_color_icon\\":\\"#198be3\\",\\"checkbox_p_i_apply_all\\":false,\\"p_i_right_unit\\":\\"px\\",\\"p_i_left_unit\\":\\"px\\",\\"p_i_left\\":\\"0\\",\\"p_i_opp_left\\":false,\\"p_i_bottom_unit\\":\\"px\\",\\"p_i_opp_bottom\\":false,\\"p_i_top_unit\\":\\"px\\",\\"m_i_right\\":\\"15\\",\\"p_i_right\\":\\"0\\",\\"f_s_i_unit\\":\\"px\\",\\"f_s_i\\":\\"24\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"cwsn837\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-mobile\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"(514)849-123\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"}],\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"checkbox_m_i_apply_all\\":false,\\"m_i_right_unit\\":\\"px\\",\\"m_i_left_unit\\":\\"px\\",\\"m_i_opp_left\\":false,\\"m_i_bottom_unit\\":\\"px\\",\\"m_i_opp_bottom\\":false,\\"m_i_top_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"font_color_icon\\":\\"#198be3\\",\\"m_i_right\\":\\"15\\",\\"checkbox_p_i_apply_all\\":false,\\"p_i_right_unit\\":\\"px\\",\\"p_i_right\\":\\"0\\",\\"p_i_left_unit\\":\\"px\\",\\"p_i_left\\":\\"0\\",\\"p_i_opp_left\\":false,\\"p_i_bottom_unit\\":\\"px\\",\\"p_i_opp_bottom\\":false,\\"p_i_top_unit\\":\\"px\\",\\"f_s_i_unit\\":\\"px\\",\\"f_s_i\\":\\"24\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"z36f838\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-time\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"Mon-Fri: 11am - 8pm <br\\\\/>Sat & Sun: 11am - 6pm\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"}],\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"checkbox_m_i_apply_all\\":false,\\"m_i_right_unit\\":\\"px\\",\\"m_i_left_unit\\":\\"px\\",\\"m_i_opp_left\\":false,\\"m_i_bottom_unit\\":\\"px\\",\\"m_i_opp_bottom\\":false,\\"m_i_top_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"m_i_bottom\\":\\"20\\",\\"font_color_icon\\":\\"#198be3\\",\\"m_i_right\\":\\"15\\",\\"checkbox_p_i_apply_all\\":false,\\"p_i_right_unit\\":\\"px\\",\\"p_i_right\\":\\"0\\",\\"p_i_left_unit\\":\\"px\\",\\"p_i_left\\":\\"0\\",\\"p_i_opp_left\\":false,\\"p_i_bottom_unit\\":\\"px\\",\\"p_i_opp_bottom\\":false,\\"p_i_top_unit\\":\\"px\\",\\"f_s_i_unit\\":\\"px\\",\\"f_s_i\\":\\"24\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"9x2m908\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-arrow-right\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"Get Direction\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"}],\\"icon_arrangement\\":\\"icon_vertical\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"checkbox_m_i_apply_all\\":false,\\"m_i_right_unit\\":\\"px\\",\\"m_i_left_unit\\":\\"px\\",\\"m_i_opp_left\\":false,\\"m_i_bottom_unit\\":\\"px\\",\\"m_i_opp_bottom\\":false,\\"m_i_top_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"icon_position\\":\\"right\\",\\"checkbox_p_i_apply_all\\":false,\\"p_i_right_unit\\":\\"px\\",\\"p_i_left_unit\\":\\"px\\",\\"p_i_opp_left\\":false,\\"p_i_bottom_unit\\":\\"px\\",\\"p_i_opp_bottom\\":false,\\"p_i_top_unit\\":\\"px\\",\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_top_style\\":\\"solid\\",\\"border_top_width\\":\\"1\\",\\"border_top_color\\":\\"#dedede\\",\\"border-type\\":\\"top\\",\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_opp_bottom\\":false,\\"padding_top_unit\\":\\"px\\",\\"padding_top\\":\\"20\\",\\"font_color_icon\\":\\"#198be3\\"}}],\\"styling\\":{\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":\\"1\\",\\"padding_opp_bottom\\":false,\\"padding_top\\":\\"2.5\\",\\"background_color\\":\\"#eef0f4\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_right\\":\\"3\\",\\"padding_left\\":\\"3\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"1.5\\"}}]}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"5\\",\\"padding_opp_bottom\\":false,\\"padding_top\\":\\"5\\"}},{\\"element_id\\":\\"r3hr820\\",\\"cols\\":[{\\"element_id\\":\\"4m6x840\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"0q3i840\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>FAQs<\\\\/h2>\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"margin_bottom_unit\\":\\"%\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"3\\",\\"margin_opp_bottom\\":false}},{\\"mod_name\\":\\"accordion\\",\\"element_id\\":\\"zgvl840\\",\\"mod_settings\\":{\\"content_accordion\\":[{\\"title_accordion\\":\\"How to Buy?\\",\\"text_accordion\\":\\"<p>You can either Order online or Shop in-store.<\\\\/p>\\\\n<p><strong>Order Online<\\\\/strong><\\\\/p>\\\\n<p>Place an order online by selecting the items you wish to purchase and adding them to cart and checkout.<\\\\/p>\\\\n<p><strong>Shop In-store<\\\\/strong><\\\\/p>\\\\n<p>Visit any one of our three stores to shop.<\\\\/p>\\",\\"default_accordion\\":\\"open\\"},{\\"title_accordion\\":\\"How to Checkout?\\",\\"text_accordion\\":\\"<p>When checking out, ensure that you fill in your complete shipping address and payment details, and place your order. You will receive a confirmation email of your order and a separate email when your items have been shipped.<\\\\/p>\\",\\"default_accordion\\":\\"closed\\"},{\\"title_accordion\\":\\"How to Payment?\\",\\"text_accordion\\":\\"<p>We accept all major credit cards and debit cards. Other payment method also include Paypal.<\\\\/p>\\",\\"default_accordion\\":\\"closed\\"},{\\"title_accordion\\":\\"How to Cancel Order?\\",\\"text_accordion\\":\\"<p>You can cancel your order online within 24 hours of placing it.<\\\\/p>\\\\n<p>If you created an account online, follow these steps to cancel your order:<\\\\/p>\\\\n<ul>\\\\n<li>Login into My Account<\\\\/li>\\\\n<li>Click on Orders and select the order # you wish to cancel<\\\\/li>\\\\n<li>Click \\\\\\"Cancel\\\\\\"<\\\\/li>\\\\n<\\\\/ul>\\\\n<p>If you wish to cancel after 24 hours and we still have\\\'t shipped your order, please send us an email at orders@gadgets.com.<\\\\/p>\\",\\"default_accordion\\":\\"closed\\"},{\\"title_accordion\\":\\"How to Become Reseller?\\",\\"text_accordion\\":\\"<p>We have a number of packages available for resellers. Contact us at reselling@gadgets.com to get in touch with one of our agents to provide you with more information, as well as, the terms and conditions.<\\\\/p>\\",\\"default_accordion\\":\\"closed\\"}],\\"accordion_appearance_accordion\\":false,\\"expand_collapse_accordion\\":\\"toggle\\",\\"icon_active_accordion\\":\\"ti-minus\\",\\"icon_accordion\\":\\"ti-plus\\",\\"color_accordion\\":\\"transparent\\",\\"b_ct_left_style\\":\\"solid\\",\\"b_ct_bottom_style\\":\\"solid\\",\\"b_ct_right_style\\":\\"solid\\",\\"b_ct_top_style\\":\\"solid\\",\\"b_ct_top_width\\":\\"1\\",\\"b_ct_top_color\\":\\"#dddddd\\",\\"b_ct-type\\":\\"top\\",\\"icon_size_unit\\":\\"px\\",\\"icon_active_color\\":\\"#198be3\\",\\"icon_color\\":\\"#198be3\\",\\"checkbox_p_a_t_apply_all\\":false,\\"p_a_t_right_unit\\":\\"px\\",\\"p_a_t_left_unit\\":\\"px\\",\\"p_a_t_opp_left\\":false,\\"p_a_t_bottom_unit\\":\\"px\\",\\"p_a_t_bottom\\":\\"26\\",\\"p_a_t_opp_bottom\\":\\"1\\",\\"p_a_t_top_unit\\":\\"px\\",\\"p_a_t_top\\":\\"26\\",\\"t_sh_t_blur_unit\\":\\"px\\",\\"t_sh_t_vShadow_unit\\":\\"px\\",\\"t_sh_t_hShadow_unit\\":\\"px\\",\\"l_s_t_unit\\":\\"em\\",\\"line_height_title_unit\\":\\"px\\",\\"font_size_title_unit\\":\\"em\\",\\"font_size_title\\":\\"1.4\\",\\"font_color_title\\":\\"#000000\\",\\"checkbox_p_ct_apply_all\\":false,\\"p_ct_right_unit\\":\\"px\\",\\"p_ct_left_unit\\":\\"px\\",\\"p_ct_opp_left\\":false,\\"p_ct_bottom_unit\\":\\"px\\",\\"p_ct_opp_bottom\\":false,\\"p_ct_top_unit\\":\\"px\\",\\"l_s_t\\":\\".03\\"}}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"4\\",\\"padding_opp_bottom\\":false}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 9,
  'post_date' => '2021-02-26 06:26:08',
  'post_date_gmt' => '2021-02-26 06:26:08',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><p><small><strong>FEATURED PRODUCT</strong></small></p> <h1>Stay connected with Google Duo</h1> <p>Make calling your loved ones much easier and much more intimate, so you never have to miss a moment!</p>
<a href="https://themify.me/" > View details </a>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/02/Gadget-featured-738x505.jpg" width="738" height="505" title="Gadget-featured" alt="Gadget-featured" srcset="https://themify.me/demo/themes/ultra-gadgets/files/2021/02/Gadget-featured.jpg 738w, https://themify.me/demo/themes/ultra-gadgets/files/2021/02/Gadget-featured-600x411.jpg 600w" sizes="(max-width: 738px) 100vw, 738px" />
<a href="https://themify.me/demo/themes/ultra-gadgets/product/xiaomi-poco-m3/" > <img loading="lazy" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/02/xiomipoco-74x112.png" width="74" height="112" title="POCO M3 " alt="MI"> </a> <h3> <a href="https://themify.me/demo/themes/ultra-gadgets/product/xiaomi-poco-m3/" > POCO M3 </a> </h3> MI
<a href="https://themify.me/demo/themes/ultra-gadgets/product/google-chrome-cast/" > <img loading="lazy" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/02/chromecast-74x112.png" width="74" height="112" title="Chromecast" alt="Google"> </a> <h3> <a href="https://themify.me/demo/themes/ultra-gadgets/product/google-chrome-cast/" > Chromecast </a> </h3> Google
<a href="https://themify.me/demo/themes/ultra-gadgets/product/redmi-powerbank/" > <img loading="lazy" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/02/redmi-powerbank-74x112.png" width="74" height="112" title="Powerbank" alt="Redmi"> </a> <h3> <a href="https://themify.me/demo/themes/ultra-gadgets/product/redmi-powerbank/" > Powerbank </a> </h3> Redmi
<a href="https://themify.me/demo/themes/ultra-gadgets/product/samsung-galaxy-sport-gear/" > <img loading="lazy" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/02/samsung-smartwatch-74x112.png" width="74" height="112" title="Smartwatch" alt="Samsung"> </a> <h3> <a href="https://themify.me/demo/themes/ultra-gadgets/product/samsung-galaxy-sport-gear/" > Smartwatch </a> </h3> Samsung
<a href="https://themify.me/demo/themes/ultra-gadgets/product/airpods/" > <img loading="lazy" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/02/airpods-74x112.png" width="74" height="112" title="Airpods" alt="Apple"> </a> <h3> <a href="https://themify.me/demo/themes/ultra-gadgets/product/airpods/" > Airpods </a> </h3> Apple
<img loading="lazy" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/02/more-74x112.png" width="74" height="112" title="More" alt="More"> <h3> More </h3>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/02/google-vr-690x498.jpg" width="690" height="498" title="google-vr" alt="google-vr" srcset="https://themify.me/demo/themes/ultra-gadgets/files/2021/02/google-vr.jpg 690w, https://themify.me/demo/themes/ultra-gadgets/files/2021/02/google-vr-600x433.jpg 600w" sizes="(max-width: 690px) 100vw, 690px" />
<h2>Entertainment that you love with a little help from Google.</h2> <p>Exclusive Google Store bundle: Buy Chromecast with Google TV and 6 months of Netflix for just $119.99 CAD.*</p>
<a href="https://themify.me/" > View product </a>
<h2>Control your comfort with a Thermostat.</h2> <p>Introducing the new Nest thermostat which is programmable, to suit your preference. Comfort control is closer than you think.</p>
<a href="https://themify.me/" > View product </a>
<img loading="lazy" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/02/thermo-690x498.jpg" width="690" height="498" title="thermo" alt="thermo" srcset="https://themify.me/demo/themes/ultra-gadgets/files/2021/02/thermo.jpg 690w, https://themify.me/demo/themes/ultra-gadgets/files/2021/02/thermo-600x433.jpg 600w" sizes="(max-width: 690px) 100vw, 690px" />
<h2>Recommended Product</h2>
<h3>Room-filling Audio Package</h3> <p>2 Nest Audio speakers</p>
<a href="https://themify.me/demo/themes/ultra-gadgets/product/google-nest-speaker/" > <img loading="lazy" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/02/nest-room-428x323.jpg" width="428" height="323" title="nest-room" alt="nest-room"> </a>
<p>Save $25</p> <h3> $234.98</h3>
<a href="https://themify.me/demo/themes/ultra-gadgets/product/google-nest-speaker/" > View product </a>
<h3>Nested Mini Speakers</h3> <p>2 Nest Audio speakers</p>
<a href="https://themify.me/demo/themes/ultra-gadgets/product/google-nest-mini-speakers/" > <img loading="lazy" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/02/nest-audio-428x323.jpg" width="428" height="323" title="nest-audio" alt="nest-audio"> </a>
<p>Save $25</p> <h3> $234.98</h3>
<a href="https://themify.me/demo/themes/ultra-gadgets/product/google-nest-mini-speakers/" > View product </a>
<h3>Nest Hub Max</h3> <p>2 Nest Audio speakers</p>
<a href="https://themify.me/demo/themes/ultra-gadgets/product/google-nest-hub-max/" > <img loading="lazy" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/02/nest-product-428x323.jpg" width="428" height="323" title="nest-product" alt="nest-product"> </a>
<p>Save $25</p> <h3> $234.98</h3>
<a href="https://themify.me/demo/themes/ultra-gadgets/product/google-nest-hub-max/" > View product </a>
<h2>Apps to push you further</h2>
<p>With thousands of apps now available on your smartphone, discover the ones that will improve your smartphone\'s features and provide the functionality for every gadget that you own.</p>
<a href="https://themify.me/"> <i><svg aria-hidden="true"><use href="#tf-ti-control-play"></use></svg></i> Recommended apps </a>
<h2>This week highlights</h2>
<ul data-lazy="1"> <li> <figure> <a href="https://themify.me/demo/themes/ultra-gadgets/product/airpods/" title="AirPods"><img loading="lazy" width="1200" height="1324" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/airpods.jpg" title="airpods" alt="airpods" srcset="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/airpods.jpg 1200w, https://themify.me/demo/themes/ultra-gadgets/files/2021/03/airpods-544x600.jpg 544w, https://themify.me/demo/themes/ultra-gadgets/files/2021/03/airpods-768x847.jpg 768w, https://themify.me/demo/themes/ultra-gadgets/files/2021/03/airpods-600x662.jpg 600w" sizes="(max-width: 1200px) 100vw, 1200px" /></a> </figure> <h3> <a href="https://themify.me/demo/themes/ultra-gadgets/product/airpods/" title="AirPods"> AirPods </a> </h3> 
 <bdi>&#36;120.00</bdi> <p><a href="?add-to-cart=89" data-quantity="1" data-product_id="89" data-product_sku="" aria-label="Add &ldquo;AirPods&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> <li> <figure> <a href="https://themify.me/demo/themes/ultra-gadgets/product/iphone-12-pro-max/" title="iPhone 12 Pro Max"><img loading="lazy" width="1200" height="1324" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/iPhone-12-max-pro.jpg" title="iPhone-12-max-pro" alt="iPhone-12-max-pro" srcset="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/iPhone-12-max-pro.jpg 1200w, https://themify.me/demo/themes/ultra-gadgets/files/2021/03/iPhone-12-max-pro-544x600.jpg 544w, https://themify.me/demo/themes/ultra-gadgets/files/2021/03/iPhone-12-max-pro-768x847.jpg 768w, https://themify.me/demo/themes/ultra-gadgets/files/2021/03/iPhone-12-max-pro-600x662.jpg 600w" sizes="(max-width: 1200px) 100vw, 1200px" /></a> </figure> <h3> <a href="https://themify.me/demo/themes/ultra-gadgets/product/iphone-12-pro-max/" title="iPhone 12 Pro Max"> iPhone 12 Pro Max </a> </h3> 
 <bdi>&#36;1,100.00</bdi> <p><a href="?add-to-cart=87" data-quantity="1" data-product_id="87" data-product_sku="" aria-label="Add &ldquo;iPhone 12 Pro Max&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> <li> <figure> <a href="https://themify.me/demo/themes/ultra-gadgets/product/google-nest-wifi-cam/" title="Google Nest Wifi Cam"><img loading="lazy" width="1200" height="1324" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/nest-cam.jpg" title="nest-cam" alt="nest-cam" srcset="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/nest-cam.jpg 1200w, https://themify.me/demo/themes/ultra-gadgets/files/2021/03/nest-cam-544x600.jpg 544w, https://themify.me/demo/themes/ultra-gadgets/files/2021/03/nest-cam-768x847.jpg 768w, https://themify.me/demo/themes/ultra-gadgets/files/2021/03/nest-cam-600x662.jpg 600w" sizes="(max-width: 1200px) 100vw, 1200px" /></a> </figure> <h3> <a href="https://themify.me/demo/themes/ultra-gadgets/product/google-nest-wifi-cam/" title="Google Nest Wifi Cam"> Google Nest Wifi Cam </a> </h3> 
 <bdi>&#36;125.00</bdi> <p><a href="?add-to-cart=85" data-quantity="1" data-product_id="85" data-product_sku="" aria-label="Add &ldquo;Google Nest Wifi Cam&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> <li> <figure> <a href="https://themify.me/demo/themes/ultra-gadgets/product/harman-kardon-onix/" title="Harman &#038; Kardon Onix"><img loading="lazy" width="1200" height="1324" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/harman-kardon-onix.jpg" title="harman-kardon-onix" alt="harman-kardon-onix" srcset="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/harman-kardon-onix.jpg 1200w, https://themify.me/demo/themes/ultra-gadgets/files/2021/03/harman-kardon-onix-544x600.jpg 544w, https://themify.me/demo/themes/ultra-gadgets/files/2021/03/harman-kardon-onix-768x847.jpg 768w, https://themify.me/demo/themes/ultra-gadgets/files/2021/03/harman-kardon-onix-600x662.jpg 600w" sizes="(max-width: 1200px) 100vw, 1200px" /></a> </figure> <h3> <a href="https://themify.me/demo/themes/ultra-gadgets/product/harman-kardon-onix/" title="Harman &#038; Kardon Onix"> Harman &#038; Kardon Onix </a> </h3> 
 <bdi>&#36;150.00</bdi> <p><a href="?add-to-cart=83" data-quantity="1" data-product_id="83" data-product_sku="" aria-label="Add &ldquo;Harman &amp; Kardon Onix&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> <li> <figure> <a href="https://themify.me/demo/themes/ultra-gadgets/product/google-nest-thermostat/" title="Google Nest Thermostat"><img loading="lazy" width="1200" height="1324" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/google-nest-thermostat.jpg" title="google-nest-thermostat" alt="google-nest-thermostat" srcset="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/google-nest-thermostat.jpg 1200w, https://themify.me/demo/themes/ultra-gadgets/files/2021/03/google-nest-thermostat-544x600.jpg 544w, https://themify.me/demo/themes/ultra-gadgets/files/2021/03/google-nest-thermostat-768x847.jpg 768w, https://themify.me/demo/themes/ultra-gadgets/files/2021/03/google-nest-thermostat-600x662.jpg 600w" sizes="(max-width: 1200px) 100vw, 1200px" /></a> </figure> <h3> <a href="https://themify.me/demo/themes/ultra-gadgets/product/google-nest-thermostat/" title="Google Nest Thermostat"> Google Nest Thermostat </a> </h3> 
 <bdi>&#36;250.00</bdi> <p><a href="?add-to-cart=81" data-quantity="1" data-product_id="81" data-product_sku="" aria-label="Add &ldquo;Google Nest Thermostat&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> <li> <figure> <a href="https://themify.me/demo/themes/ultra-gadgets/product/samsung-galaxy-sport-gear/" title="Samsung Galaxy Sport Gear"><img loading="lazy" width="1200" height="1324" src="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/samsung-galaxy-gear-sport.jpg" title="samsung-galaxy-gear-sport" alt="samsung-galaxy-gear-sport" srcset="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/samsung-galaxy-gear-sport.jpg 1200w, https://themify.me/demo/themes/ultra-gadgets/files/2021/03/samsung-galaxy-gear-sport-544x600.jpg 544w, https://themify.me/demo/themes/ultra-gadgets/files/2021/03/samsung-galaxy-gear-sport-768x847.jpg 768w, https://themify.me/demo/themes/ultra-gadgets/files/2021/03/samsung-galaxy-gear-sport-600x662.jpg 600w" sizes="(max-width: 1200px) 100vw, 1200px" /></a> </figure> <h3> <a href="https://themify.me/demo/themes/ultra-gadgets/product/samsung-galaxy-sport-gear/" title="Samsung Galaxy Sport Gear"> Samsung Galaxy Sport Gear </a> </h3> 
 <bdi>&#36;350.00</bdi> <p><a href="?add-to-cart=79" data-quantity="1" data-product_id="79" data-product_sku="" aria-label="Add &ldquo;Samsung Galaxy Sport Gear&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> </ul><!--/themify_builder_static-->',
  'post_title' => 'Home',
  'post_excerpt' => '',
  'post_name' => 'home',
  'post_modified' => '2021-03-29 00:16:42',
  'post_modified_gmt' => '2021-03-29 00:16:42',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-gadgets/?page_id=9',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'section_scrolling_mobile' => 'on',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"5kg7506\\",\\"cols\\":[{\\"element_id\\":\\"kn3o507\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"3i30355\\",\\"cols\\":[{\\"element_id\\":\\"08dg359\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"wnem283\\",\\"mod_settings\\":{\\"content_text\\":\\"<p><small><strong>FEATURED PRODUCT<\\\\/strong><\\\\/small><\\\\/p>\\\\n<h1>Stay connected with Google Duo<\\\\/h1>\\\\n<p>Make calling your loved ones much easier and much more intimate, so you never have to miss a moment!<\\\\/p>\\",\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"upvg908\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"View details\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"blue\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"circle\\",\\"buttons_size\\":\\"normal\\"}}],\\"styling\\":{\\"padding_left\\":\\"50\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false}},{\\"element_id\\":\\"ii1q360\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"pbz2354\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/02\\\\/Gadget-featured.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-right\\",\\"height_image\\":\\"505\\",\\"width_image\\":\\"738\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"gutter\\":\\"gutter-none\\",\\"styling\\":{\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false,\\"padding_top\\":35,\\"padding_opp_top\\":\\"1\\",\\"padding_bottom\\":35,\\"padding_bottom_unit\\":\\"px\\",\\"padding_top_unit\\":\\"px\\"}}],\\"styling\\":{\\"background_color\\":\\"#e6e7ea\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"b_ra_bottom\\":\\"10\\",\\"b_ra_left\\":\\"10\\",\\"b_ra_opp_left\\":false,\\"b_ra_right\\":\\"10\\",\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"10\\"}}],\\"styling\\":{\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"6\\",\\"padding_top\\":30}},{\\"element_id\\":\\"or0k160\\",\\"cols\\":[{\\"element_id\\":\\"ghos161\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"w6lk460\\",\\"mod_settings\\":{\\"caption_image\\":\\"MI\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"POCO M3 \\",\\"height_image\\":\\"112\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"74\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/02\\\\/xiomipoco.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/product\\\\/xiaomi-poco-m3\\\\/\\"}}],\\"styling\\":{\\"margin-top_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false,\\"padding_bottom\\":\\"15\\",\\"padding_top\\":\\"20\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color-type\\":\\"color\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"b_c_h\\":\\"#f8f8f8\\",\\"b_p_h\\":\\"50,50\\",\\"b_a_h\\":\\"scroll\\",\\"b_r_h\\":\\"repeat\\",\\"b_g_h-circle-radial\\":false,\\"b_t_h\\":\\"image\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"ixot612\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"bebb614\\",\\"mod_settings\\":{\\"caption_image\\":\\"Google\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Chromecast\\",\\"height_image\\":\\"112\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"74\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/02\\\\/chromecast.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":\\"1\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/product\\\\/google-chrome-cast\\\\/\\"}}],\\"styling\\":{\\"margin-top_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"20\\",\\"padding_top\\":\\"20\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color-type\\":\\"color\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"b_c_h\\":\\"#f8f8f8\\",\\"b_p_h\\":\\"50,50\\",\\"b_a_h\\":\\"scroll\\",\\"b_r_h\\":\\"repeat\\",\\"b_g_h-circle-radial\\":false,\\"b_t_h\\":\\"image\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"eluu827\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"ntzz827\\",\\"mod_settings\\":{\\"caption_image\\":\\"Redmi\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Powerbank\\",\\"height_image\\":\\"112\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"74\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/02\\\\/redmi-powerbank.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/product\\\\/redmi-powerbank\\\\/\\"}}],\\"styling\\":{\\"margin-top_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"20\\",\\"padding_top\\":\\"20\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color-type\\":\\"color\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"b_c_h\\":\\"#f8f8f8\\",\\"b_p_h\\":\\"50,50\\",\\"b_a_h\\":\\"scroll\\",\\"b_r_h\\":\\"repeat\\",\\"b_g_h-circle-radial\\":false,\\"b_t_h\\":\\"image\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"ot67115\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"821i115\\",\\"mod_settings\\":{\\"caption_image\\":\\"Samsung\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Smartwatch\\",\\"height_image\\":\\"112\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"74\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/02\\\\/samsung-smartwatch.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/product\\\\/samsung-galaxy-sport-gear\\\\/\\"}}],\\"styling\\":{\\"margin-top_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"20\\",\\"padding_top\\":\\"20\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color-type\\":\\"color\\",\\"r_c_opp_left\\":false,\\"r_c_opp_top\\":false,\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"b_c_h\\":\\"#f8f8f8\\",\\"b_p_h\\":\\"50,50\\",\\"b_a_h\\":\\"scroll\\",\\"b_r_h\\":\\"repeat\\",\\"b_g_h-circle-radial\\":false,\\"b_t_h\\":\\"image\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"z16d365\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"fftm365\\",\\"mod_settings\\":{\\"caption_image\\":\\"Apple\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Airpods\\",\\"height_image\\":\\"112\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"74\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/02\\\\/airpods.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/product\\\\/airpods\\\\/\\"}}],\\"styling\\":{\\"margin-top_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"20\\",\\"padding_top\\":\\"20\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color-type\\":\\"color\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"b_c_h\\":\\"#f8f8f8\\",\\"b_p_h\\":\\"50,50\\",\\"b_a_h\\":\\"scroll\\",\\"b_r_h\\":\\"repeat\\",\\"b_g_h-circle-radial\\":false,\\"b_t_h\\":\\"image\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"6g62716\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"jekl717\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"More\\",\\"height_image\\":\\"112\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"74\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/02\\\\/more.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\"}}],\\"styling\\":{\\"margin-top_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"20\\",\\"padding_top\\":\\"20\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color-type\\":\\"color\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"b_c_h\\":\\"#f8f8f8\\",\\"b_p_h\\":\\"50,50\\",\\"b_a_h\\":\\"scroll\\",\\"b_r_h\\":\\"repeat\\",\\"b_g_h-circle-radial\\":false,\\"b_t_h\\":\\"image\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}]},{\\"element_id\\":\\"2vjj141\\",\\"cols\\":[{\\"element_id\\":\\"2w86142\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"j5vy518\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"498\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"690\\",\\"appearance_image\\":\\"rounded\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/02\\\\/google-vr.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\"}}]},{\\"element_id\\":\\"6u4699\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"7z5d767\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Entertainment that you love with a little help from Google.<\\\\/h2>\\\\n<p>Exclusive Google Store bundle: Buy Chromecast with Google TV and 6 months of Netflix for just $119.99 CAD.*<\\\\/p>\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"12i2189\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"View product\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"blue\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"circle\\",\\"buttons_size\\":\\"normal\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false,\\"padding_top\\":\\"6\\"}},{\\"element_id\\":\\"ofik434\\",\\"cols\\":[{\\"element_id\\":\\"cxub435\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"y9lz435\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Control your comfort with a Thermostat.<\\\\/h2>\\\\n<p>Introducing the new Nest thermostat which is programmable, to suit your preference. Comfort control is closer than you think.<\\\\/p>\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"cn48436\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"View product\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"blue\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"circle\\",\\"buttons_size\\":\\"normal\\"}}]},{\\"element_id\\":\\"v5dh435\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"o3mu435\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"498\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"690\\",\\"appearance_image\\":\\"rounded\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/02\\\\/thermo.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"styling\\":{\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false}},{\\"element_id\\":\\"q6e4386\\",\\"cols\\":[{\\"element_id\\":\\"jeb4386\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"io72979\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Recommended Product<\\\\/h2>\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"50\\",\\"margin_opp_bottom\\":false}},{\\"element_id\\":\\"6t7v783\\",\\"cols\\":[{\\"element_id\\":\\"hxqp784\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"eduk826\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Room-filling Audio Package<\\\\/h3>\\\\n<p>2 Nest Audio speakers<\\\\/p>\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"22\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"us9v657\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"323\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"428\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/02\\\\/nest-room.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/product\\\\/google-nest-speaker\\\\/\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"196i379\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>Save $25<\\\\/p>\\\\n<h3> $234.98<\\\\/h3>\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"22\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"p_margin_bottom_unit\\":\\"px\\",\\"p_margin_bottom\\":\\"10\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false,\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"m6ii466\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"View product\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/product\\\\/google-nest-speaker\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"blue\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"circle\\",\\"buttons_size\\":\\"normal\\",\\"alignment\\":\\"center\\"}}],\\"styling\\":{\\"background_color\\":\\"#e6e7ea\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"40\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top\\":\\"40\\",\\"b_ra_bottom\\":\\"8\\",\\"b_ra_left\\":\\"8\\",\\"b_ra_opp_left\\":\\"1\\",\\"b_ra_right\\":\\"8\\",\\"b_ra_opp_top\\":\\"1\\",\\"b_ra_top\\":\\"8\\"}},{\\"element_id\\":\\"bztw582\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"du4d583\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Nested Mini Speakers<\\\\/h3>\\\\n<p>2 Nest Audio speakers<\\\\/p>\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"22\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"073c584\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"323\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"428\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/02\\\\/nest-audio.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/product\\\\/google-nest-mini-speakers\\\\/\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"8wux584\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>Save $25<\\\\/p>\\\\n<h3> $234.98<\\\\/h3>\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"22\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"p_margin_bottom_unit\\":\\"px\\",\\"p_margin_bottom\\":\\"10\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"20\\",\\"padding_opp_left\\":false}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"mkii584\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"View product\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/product\\\\/google-nest-mini-speakers\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"blue\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"circle\\",\\"buttons_size\\":\\"normal\\",\\"alignment\\":\\"center\\"}}],\\"styling\\":{\\"background_color\\":\\"#e6e7ea\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"40\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top\\":\\"40\\",\\"b_ra_bottom\\":\\"8\\",\\"b_ra_left\\":\\"8\\",\\"b_ra_opp_left\\":\\"1\\",\\"b_ra_right\\":\\"8\\",\\"b_ra_opp_top\\":\\"1\\",\\"b_ra_top\\":\\"8\\"}},{\\"element_id\\":\\"ovqe362\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"px20362\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Nest Hub Max<\\\\/h3>\\\\n<p>2 Nest Audio speakers<\\\\/p>\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"22\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"0vcd362\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"323\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"428\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/02\\\\/nest-product.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/product\\\\/google-nest-hub-max\\\\/\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"q5am363\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>Save $25<\\\\/p>\\\\n<h3> $234.98<\\\\/h3>\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"22\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"p_margin_bottom_unit\\":\\"px\\",\\"p_margin_bottom\\":\\"10\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"20\\",\\"padding_opp_left\\":false}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"k3m6363\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"View product\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/product\\\\/google-nest-hub-max\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"blue\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"circle\\",\\"buttons_size\\":\\"normal\\",\\"alignment\\":\\"center\\"}}],\\"styling\\":{\\"background_color\\":\\"#e6e7ea\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"40\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top\\":\\"40\\",\\"b_ra_bottom\\":\\"8\\",\\"b_ra_left\\":\\"8\\",\\"b_ra_opp_left\\":\\"1\\",\\"b_ra_right\\":\\"8\\",\\"b_ra_opp_top\\":\\"1\\",\\"b_ra_top\\":\\"8\\"}}],\\"gutter\\":\\"gutter-narrow\\"}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"6\\",\\"padding_opp_bottom\\":false,\\"padding_top\\":\\"6\\"}},{\\"element_id\\":\\"p99r354\\",\\"cols\\":[{\\"element_id\\":\\"1tax354\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"12ji964\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Apps to push you further<\\\\/h2>\\"}},{\\"element_id\\":\\"684k760\\",\\"cols\\":[{\\"element_id\\":\\"yoci761\\",\\"grid_class\\":\\"col4-1\\"},{\\"element_id\\":\\"xu03761\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"lm71713\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>With thousands of apps now available on your smartphone, discover the ones that will improve your smartphone\\\'s features and provide the functionality for every gadget that you own.<\\\\/p>\\"}}]},{\\"element_id\\":\\"6qic46\\",\\"grid_class\\":\\"col4-1\\"}]},{\\"element_id\\":\\"efzg941\\",\\"cols\\":[{\\"element_id\\":\\"cq37942\\",\\"grid_class\\":\\"col3-1\\"},{\\"element_id\\":\\"x2wy943\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"tct2223\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-control-play\\",\\"label\\":\\"Recommended apps\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"icon_color_bg\\":\\"tb_default_color\\"}],\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"large\\",\\"font_color_icon\\":\\"#198be3\\",\\"background_color_icon\\":\\"#ffffff_0.10\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-circle-radial\\":false,\\"background_image-gradient-angle\\":\\"180\\",\\"background_image-gradient-type\\":\\"linear\\",\\"background_image-type\\":\\"image\\",\\"link_color\\":\\"#ffffff\\",\\"checkbox_m_i_apply_all\\":false,\\"m_i_right_unit\\":\\"px\\",\\"m_i_right\\":\\"15\\",\\"m_i_left_unit\\":\\"px\\",\\"m_i_opp_left\\":false,\\"m_i_bottom_unit\\":\\"px\\",\\"m_i_opp_bottom\\":false,\\"m_i_top_unit\\":\\"px\\",\\"f_s_i_unit\\":\\"px\\",\\"f_s_i\\":\\"24\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_size\\":\\"14\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"}}]},{\\"element_id\\":\\"itnt943\\",\\"grid_class\\":\\"col3-1\\"}],\\"gutter\\":\\"gutter-none\\"}]}],\\"styling\\":{\\"padding_top\\":\\"12\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"12\\",\\"padding_opp_bottom\\":\\"1\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/02\\\\/banner-gadget-bottom.jpg\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"cover_color\\":\\"#000000_0.40\\",\\"cover_color-type\\":\\"color\\",\\"text_align\\":\\"center\\",\\"font_color\\":\\"#ffffff\\",\\"cover_color_hover\\":\\"#000000_0.30\\",\\"cover_color_hover-type\\":\\"hover_color\\"}},{\\"element_id\\":\\"223g674\\",\\"cols\\":[{\\"element_id\\":\\"440j674\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"8tpj807\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>This week highlights<\\\\/h2>\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"50\\",\\"margin_opp_bottom\\":false}},{\\"mod_name\\":\\"products\\",\\"element_id\\":\\"uy6772\\",\\"mod_settings\\":{\\"post_per_page_products\\":\\"6\\",\\"hide_page_nav_products\\":\\"yes\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"layout_products\\":\\"auto_tiles\\",\\"hide_sales_badge\\":\\"no\\",\\"show_empty_rating\\":false,\\"hide_rating_products\\":\\"no\\",\\"hide_add_to_cart_products\\":\\"no\\",\\"hide_price_products\\":\\"no\\",\\"unlink_post_title_products\\":\\"no\\",\\"show_product_tags\\":\\"no\\",\\"show_product_categories\\":\\"no\\",\\"hide_post_title_products\\":\\"no\\",\\"unlink_feat_img_products\\":\\"no\\",\\"hide_feat_img_products\\":\\"no\\",\\"description_products\\":\\"none\\",\\"height_slider\\":\\"variable\\",\\"show_arrow_buttons_vertical\\":false,\\"show_arrow_slider\\":\\"yes\\",\\"show_nav_slider\\":\\"yes\\",\\"wrap_slider\\":\\"yes\\",\\"play_pause_control\\":\\"no\\",\\"speed_opt_slider\\":\\"normal\\",\\"scroll_opt_slider\\":\\"1\\",\\"auto_scroll_opt_slider\\":\\"1\\",\\"mob_visible_opt_slider\\":\\"0\\",\\"tab_visible_opt_slider\\":\\"0\\",\\"visible_opt_slider\\":\\"1\\",\\"effect_slider\\":\\"scroll\\",\\"layout_slider\\":\\"slider-default\\",\\"template_products\\":\\"list\\",\\"order_products\\":\\"desc\\",\\"orderby_products\\":\\"date\\",\\"hide_outofstock_products\\":\\"no\\",\\"hide_free_products\\":\\"no\\",\\"tag_products\\":\\"0|single\\",\\"hide_child_products\\":\\"no\\",\\"category_products\\":\\"0|single\\",\\"query_type\\":\\"category\\",\\"query_products\\":\\"all\\"}}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"6\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top\\":\\"6\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 89,
  'post_date' => '2021-03-04 05:01:21',
  'post_date_gmt' => '2021-03-04 05:01:21',
  'post_content' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
  'post_title' => 'AirPods',
  'post_excerpt' => 'Voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est qui dolorem ipsum.',
  'post_name' => 'airpods',
  'post_modified' => '2021-03-04 05:01:21',
  'post_modified_gmt' => '2021-03-04 05:01:21',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-gadgets/?post_type=product&#038;p=89',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615274408:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"c2p2479\\",\\"cols\\":[{\\"element_id\\":\\"ybjk480\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '90',
    '_regular_price' => '120',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '120',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'audio',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-gadgets/files/2021/03/airpods.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 87,
  'post_date' => '2021-03-04 04:59:26',
  'post_date_gmt' => '2021-03-04 04:59:26',
  'post_content' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
  'post_title' => 'iPhone 12 Pro Max',
  'post_excerpt' => 'Voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.',
  'post_name' => 'iphone-12-pro-max',
  'post_modified' => '2021-03-04 04:59:26',
  'post_modified_gmt' => '2021-03-04 04:59:26',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-gadgets/?post_type=product&#038;p=87',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615274092:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"22ox22\\",\\"cols\\":[{\\"element_id\\":\\"0uz624\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '88',
    '_regular_price' => '1100',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '1100',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'smartphone',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-gadgets/files/2021/03/iPhone-12-max-pro.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 85,
  'post_date' => '2021-03-04 04:49:15',
  'post_date_gmt' => '2021-03-04 04:49:15',
  'post_content' => 'Deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum. Excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum.',
  'post_title' => 'Google Nest Wifi Cam',
  'post_excerpt' => 'Vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias.',
  'post_name' => 'google-nest-wifi-cam',
  'post_modified' => '2021-03-04 04:49:15',
  'post_modified_gmt' => '2021-03-04 04:49:15',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-gadgets/?post_type=product&#038;p=85',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615273998:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"6na969\\",\\"cols\\":[{\\"element_id\\":\\"mfhi70\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '86',
    '_regular_price' => '125',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '125',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hub',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-gadgets/files/2021/03/nest-cam.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 83,
  'post_date' => '2021-03-04 04:45:49',
  'post_date_gmt' => '2021-03-04 04:45:49',
  'post_content' => 'Molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae.Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus.',
  'post_title' => 'Harman & Kardon Onix',
  'post_excerpt' => 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit.',
  'post_name' => 'harman-kardon-onix',
  'post_modified' => '2021-03-04 04:45:49',
  'post_modified_gmt' => '2021-03-04 04:45:49',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-gadgets/?post_type=product&#038;p=83',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615273951:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"7mtn101\\",\\"cols\\":[{\\"element_id\\":\\"5cbv102\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '84',
    '_regular_price' => '150',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '150',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'audio',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-gadgets/files/2021/03/harman-kardon-onix.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 81,
  'post_date' => '2021-03-04 04:44:27',
  'post_date_gmt' => '2021-03-04 04:44:27',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_title' => 'Google Nest Thermostat',
  'post_excerpt' => 'Eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.

',
  'post_name' => 'google-nest-thermostat',
  'post_modified' => '2021-03-04 04:44:27',
  'post_modified_gmt' => '2021-03-04 04:44:27',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-gadgets/?post_type=product&#038;p=81',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615273896:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"i4bh468\\",\\"cols\\":[{\\"element_id\\":\\"qx8m469\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '82',
    '_regular_price' => '250',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '250',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hub',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-gadgets/files/2021/03/google-nest-thermostat.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 79,
  'post_date' => '2021-03-04 04:43:14',
  'post_date_gmt' => '2021-03-04 04:43:14',
  'post_content' => ' Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid.',
  'post_title' => 'Samsung Galaxy Sport Gear',
  'post_excerpt' => 'Totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.',
  'post_name' => 'samsung-galaxy-sport-gear',
  'post_modified' => '2021-03-04 04:43:14',
  'post_modified_gmt' => '2021-03-04 04:43:14',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-gadgets/?post_type=product&#038;p=79',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615273840:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"k6p7164\\",\\"cols\\":[{\\"element_id\\":\\"w23a165\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '80',
    '_regular_price' => '350',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '350',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'smartwatch',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-gadgets/files/2021/03/samsung-galaxy-gear-sport.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 77,
  'post_date' => '2021-03-04 04:40:45',
  'post_date_gmt' => '2021-03-04 04:40:45',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus.',
  'post_title' => 'JBL Wireless Headphone Audio',
  'post_excerpt' => 'Magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur.',
  'post_name' => 'jbl-wireless-headphone-audio',
  'post_modified' => '2021-03-04 04:40:45',
  'post_modified_gmt' => '2021-03-04 04:40:45',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-gadgets/?post_type=product&#038;p=77',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615273733:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"1vd7680\\",\\"cols\\":[{\\"element_id\\":\\"wjgw681\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '78',
    '_regular_price' => '300',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '300',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'audio',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-gadgets/files/2021/03/jbl-audio-headphone.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 75,
  'post_date' => '2021-03-04 04:39:13',
  'post_date_gmt' => '2021-03-04 04:39:13',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus.',
  'post_title' => 'Garmin Fenix 5',
  'post_excerpt' => 'Magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur.',
  'post_name' => 'garmin-fenix-5',
  'post_modified' => '2021-03-04 04:39:13',
  'post_modified_gmt' => '2021-03-04 04:39:13',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-gadgets/?post_type=product&#038;p=75',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615273599:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"ou9y844\\",\\"cols\\":[{\\"element_id\\":\\"skpj845\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '76',
    '_regular_price' => '800',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '800',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'smartwatch',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-gadgets/files/2021/03/garmin-fenix-5.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 73,
  'post_date' => '2021-03-04 04:36:36',
  'post_date_gmt' => '2021-03-04 04:36:36',
  'post_content' => 'Molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae.Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus.

',
  'post_title' => 'Amazon Echo Dot 3rd Gen',
  'post_excerpt' => 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo.',
  'post_name' => 'amazon-echo-dot-3rd-gen',
  'post_modified' => '2021-03-04 04:36:55',
  'post_modified_gmt' => '2021-03-04 04:36:55',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-gadgets/?post_type=product&#038;p=73',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615273531:172',
    '_edit_last' => '172',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_regular_price' => '45',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '45',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"7m4s235\\",\\"cols\\":[{\\"element_id\\":\\"4okk236\\",\\"grid_class\\":\\"col-full\\"}]}]',
    '_thumbnail_id' => '74',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hub',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-gadgets/files/2021/03/amazon-nest.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 71,
  'post_date' => '2021-03-04 04:20:08',
  'post_date_gmt' => '2021-03-04 04:20:08',
  'post_content' => 'Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.',
  'post_title' => 'Segway Ninebot S Pro',
  'post_excerpt' => 'Nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur.',
  'post_name' => 'segway-ninebot-s-pro',
  'post_modified' => '2021-03-04 04:20:44',
  'post_modified_gmt' => '2021-03-04 04:20:44',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-gadgets/?post_type=product&#038;p=71',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615273407:172',
    '_edit_last' => '172',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '72',
    '_regular_price' => '800',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '800',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"068o151\\",\\"cols\\":[{\\"element_id\\":\\"h6ji152\\",\\"grid_class\\":\\"col-full\\"}]}]',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'segway',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-gadgets/files/2021/03/ninebot-spro.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 107,
  'post_date' => '2021-03-03 06:26:41',
  'post_date_gmt' => '2021-03-03 06:26:41',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid.',
  'post_title' => 'Google Nest Mini Speakers',
  'post_excerpt' => 'Totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.',
  'post_name' => 'google-nest-mini-speakers',
  'post_modified' => '2021-03-10 06:38:36',
  'post_modified_gmt' => '2021-03-10 06:38:36',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-gadgets/?post_type=product&#038;p=107',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615358316:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"y7b3447\\",\\"cols\\":[{\\"element_id\\":\\"tm6b448\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '108',
    '_regular_price' => '100',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '100',
    '_wp_old_date' => '2021-03-10',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'audio',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-gadgets/files/2021/03/google-nest-mini.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 105,
  'post_date' => '2021-03-03 06:23:08',
  'post_date_gmt' => '2021-03-03 06:23:08',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus.

',
  'post_title' => 'Google Nest Speaker',
  'post_excerpt' => 'Magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur.',
  'post_name' => 'google-nest-speaker',
  'post_modified' => '2021-03-10 06:38:28',
  'post_modified_gmt' => '2021-03-10 06:38:28',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-gadgets/?post_type=product&#038;p=105',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615358308:172',
    '_edit_last' => '172',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '106',
    '_regular_price' => '234',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '234',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"rdjz14\\",\\"cols\\":[{\\"element_id\\":\\"ocbn15\\",\\"grid_class\\":\\"col-full\\"}]}]',
    '_wp_old_date' => '2021-03-10',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'audio',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-gadgets/files/2021/03/google-nest.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 117,
  'post_date' => '2021-03-02 06:32:22',
  'post_date_gmt' => '2021-03-02 06:32:22',
  'post_content' => 'Molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae.Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus.',
  'post_title' => 'Google Chrome Cast',
  'post_excerpt' => 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit.',
  'post_name' => 'google-chrome-cast',
  'post_modified' => '2021-03-10 06:38:50',
  'post_modified_gmt' => '2021-03-10 06:38:50',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-gadgets/?post_type=product&#038;p=117',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615358330:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"cz1b344\\",\\"cols\\":[{\\"element_id\\":\\"mrv8345\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '118',
    '_regular_price' => '60',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '60',
    '_wp_old_date' => '2021-03-10',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'audio, hub',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-gadgets/files/2021/03/chromecast.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 111,
  'post_date' => '2021-03-02 06:28:14',
  'post_date_gmt' => '2021-03-02 06:28:14',
  'post_content' => 'Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.',
  'post_title' => 'Google Nest Hub Max',
  'post_excerpt' => 'Nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur.',
  'post_name' => 'google-nest-hub-max',
  'post_modified' => '2021-03-10 06:38:45',
  'post_modified_gmt' => '2021-03-10 06:38:45',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-gadgets/?post_type=product&#038;p=111',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615358325:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"cx9c392\\",\\"cols\\":[{\\"element_id\\":\\"eel8395\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '112',
    '_regular_price' => '360',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '360',
    '_wp_old_date' => '2021-03-10',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'audio, hub',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-gadgets/files/2021/03/google-nest-hub.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 120,
  'post_date' => '2021-03-01 06:33:59',
  'post_date_gmt' => '2021-03-01 06:33:59',
  'post_content' => 'Deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum. Excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum.',
  'post_title' => 'Redmi Powerbank',
  'post_excerpt' => 'Vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias.',
  'post_name' => 'redmi-powerbank',
  'post_modified' => '2021-03-10 06:38:54',
  'post_modified_gmt' => '2021-03-10 06:38:54',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-gadgets/?post_type=product&#038;p=120',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615358334:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"um7t954\\",\\"cols\\":[{\\"element_id\\":\\"kfzz956\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '121',
    '_regular_price' => '25',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '25',
    '_wp_old_date' => '2021-03-10',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'smartphone',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-gadgets/files/2021/03/redmi-powerbank.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 114,
  'post_date' => '2021-03-01 06:30:36',
  'post_date_gmt' => '2021-03-01 06:30:36',
  'post_content' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
  'post_title' => 'Xiaomi Poco M3',
  'post_excerpt' => 'Voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est qui dolorem ipsum.
',
  'post_name' => 'xiaomi-poco-m3',
  'post_modified' => '2021-03-10 06:39:30',
  'post_modified_gmt' => '2021-03-10 06:39:30',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-gadgets/?post_type=product&#038;p=114',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615358370:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"0p7z534\\",\\"cols\\":[{\\"element_id\\":\\"biaj535\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    '_thumbnail_id' => '115',
    '_regular_price' => '250',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '250',
    '_wp_old_date' => '2021-03-10',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'smartphone',
  ),
  'thumb' => 'https://themify.me/demo/themes/ultra-gadgets/files/2021/03/xiaomi-poco-m3.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 92,
  'post_date' => '2021-03-04 05:15:25',
  'post_date_gmt' => '2021-03-04 05:15:25',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '92',
  'post_modified' => '2021-03-22 01:48:28',
  'post_modified_gmt' => '2021-03-22 01:48:28',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-gadgets/?p=92',
  'menu_order' => 1,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '9',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 185,
  'post_date' => '2021-03-20 11:16:55',
  'post_date_gmt' => '2021-03-20 11:16:55',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '185',
  'post_modified' => '2021-03-22 01:48:28',
  'post_modified_gmt' => '2021-03-22 01:48:28',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-gadgets/?p=185',
  'menu_order' => 2,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'taxonomy',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '19',
    '_menu_item_object' => 'product_cat',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 186,
  'post_date' => '2021-03-20 11:16:55',
  'post_date_gmt' => '2021-03-20 11:16:55',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '186',
  'post_modified' => '2021-03-22 01:48:28',
  'post_modified_gmt' => '2021-03-22 01:48:28',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-gadgets/?p=186',
  'menu_order' => 3,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'taxonomy',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '17',
    '_menu_item_object' => 'product_cat',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 187,
  'post_date' => '2021-03-20 11:16:55',
  'post_date_gmt' => '2021-03-20 11:16:55',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '187',
  'post_modified' => '2021-03-22 01:48:28',
  'post_modified_gmt' => '2021-03-22 01:48:28',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-gadgets/?p=187',
  'menu_order' => 4,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'taxonomy',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '20',
    '_menu_item_object' => 'product_cat',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 192,
  'post_date' => '2021-03-22 01:48:28',
  'post_date_gmt' => '2021-03-22 01:48:28',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '192',
  'post_modified' => '2021-03-22 01:48:28',
  'post_modified_gmt' => '2021-03-22 01:48:28',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-gadgets/?p=192',
  'menu_order' => 5,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '128',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 191,
  'post_date' => '2021-03-22 01:48:28',
  'post_date_gmt' => '2021-03-22 01:48:28',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '191',
  'post_modified' => '2021-03-22 01:48:28',
  'post_modified_gmt' => '2021-03-22 01:48:28',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/ultra-gadgets/?p=191',
  'menu_order' => 6,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '175',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$widgets = get_option( "widget_text" );
$widgets[1002] = array (
  'title' => '',
  'text' => '<h3><a href="https://themify.me/demo/themes/ultra-gadgets">GADGETS</a></h3>
2406 Brook St, Newcombville Nova Scotia, Canada

<a href="mailto:info@gedgets.com">info@gedgets.com</a>

<a href="tel:017-624-1234">017-624-1234</a>',
  'filter' => true,
  'visual' => true,
  'tf_search_ajax' => '',
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1003] = array (
  'title' => 'Shop',
  'text' => '<a href="#">Best Sellers</a>

<a href="#">Computers</a>

<a href="#">Audio TV</a>

<a href="#">Applicances</a>',
  'filter' => true,
  'visual' => true,
  'tf_search_ajax' => '',
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1004] = array (
  'title' => 'Information',
  'text' => '<a href="#">About Us</a>

<a href="#">Blogs</a>

<a href="#">Contact Us</a>

<a href="#">Orders &amp; Shipping</a>

<a href="#">Billing &amp; payments</a>',
  'filter' => true,
  'visual' => true,
  'tf_search_ajax' => '',
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1005] = array (
  'title' => 'Support',
  'text' => '<a href="#">Order Status</a>

<a href="#">Refund Policies</a>

<a href="#">Complaints</a>

<a href="#">Help</a>

<a href="#">Contact</a>',
  'filter' => true,
  'visual' => true,
  'tf_search_ajax' => '',
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_search" );
$widgets[1006] = array (
  'title' => '',
);
update_option( "widget_search", $widgets );

$widgets = get_option( "widget_recent-posts" );
$widgets[1007] = array (
  'title' => '',
  'number' => 5,
);
update_option( "widget_recent-posts", $widgets );

$widgets = get_option( "widget_recent-comments" );
$widgets[1008] = array (
  'title' => '',
  'number' => 5,
);
update_option( "widget_recent-comments", $widgets );

$widgets = get_option( "widget_archives" );
$widgets[1009] = array (
  'title' => '',
  'count' => 0,
  'dropdown' => 0,
);
update_option( "widget_archives", $widgets );

$widgets = get_option( "widget_categories" );
$widgets[1010] = array (
  'title' => '',
  'count' => 0,
  'hierarchical' => 0,
  'dropdown' => 0,
);
update_option( "widget_categories", $widgets );

$widgets = get_option( "widget_meta" );
$widgets[1011] = array (
  'title' => '',
);
update_option( "widget_meta", $widgets );



$sidebars_widgets = array (
  'footer-widget-1' => 
  array (
    0 => 'text-1002',
  ),
  'footer-widget-2' => 
  array (
    0 => 'text-1003',
  ),
  'footer-widget-3' => 
  array (
    0 => 'text-1004',
  ),
  'footer-widget-4' => 
  array (
    0 => 'text-1005',
  ),
  'sidebar-main' => 
  array (
    0 => 'search-1006',
    1 => 'recent-posts-1007',
    2 => 'recent-comments-1008',
  ),
  'sidebar-alt' => 
  array (
    0 => 'archives-1009',
    1 => 'categories-1010',
    2 => 'meta-1011',
  ),
); 
update_option( "sidebars_widgets", $sidebars_widgets );

$homepage = get_posts( array( 'name' => 'home', 'post_type' => 'page' ) );
			if( is_array( $homepage ) && ! empty( $homepage ) ) {
				update_option( 'show_on_front', 'page' );
				update_option( 'page_on_front', $homepage[0]->ID );
			}
			$themify_data = array (
  'setting-search_post_type' => 'all',
  'setting-webfonts_list' => 'recommended',
  'setting-lazy-blur' => '25',
  'setting-cache-live' => '10080',
  'setting-default_layout' => 'sidebar1',
  'setting-default_post_layout' => 'list-post',
  'setting-post_filter' => 'no',
  'setting-disable_masonry' => 'yes',
  'setting-post_gutter' => 'gutter',
  'setting-default_layout_display' => 'content',
  'setting-default_more_text' => 'More',
  'setting-index_orderby' => 'date',
  'setting-index_order' => 'DESC',
  'setting-default_media_position' => 'above',
  'setting-image_post_feature_size' => 'blank',
  'setting-default_page_post_layout' => 'sidebar1',
  'setting-default_page_post_layout_type' => 'classic',
  'setting-default_page_single_media_position' => 'above',
  'setting-image_post_single_feature_size' => 'blank',
  'setting-search-result_layout_display' => 'excerpt',
  'setting-search-result_media_position' => 'above',
  'setting-default_page_layout' => 'sidebar1',
  'setting-default_portfolio_index_layout' => 'sidebar-none',
  'setting-default_portfolio_index_post_layout' => 'grid3',
  'setting-portfolio_post_filter' => 'yes',
  'setting-portfolio_disable_masonry' => 'yes',
  'setting-portfolio_gutter' => 'gutter',
  'setting-default_portfolio_index_display' => 'none',
  'setting-default_portfolio_single_layout' => 'sidebar-none',
  'setting-default_portfolio_single_portfolio_layout_type' => 'fullwidth',
  'themify_portfolio_slug' => 'project',
  'themify_portfolio_category_slug' => 'portfolio-category',
  'setting-shop_layout' => 'sidebar-none',
  'setting-shop_archive_layout' => 'sidebar-none',
  'setting-products_layout' => 'grid3',
  'setting-product_disable_masonry' => 'yes',
  'setting-product_hover_image' => 'on',
  'setting-product_shop_image_size' => 'woocommerce',
  'setting-single_product_layout' => 'sidebar-none',
  'setting-product_single_image_size' => 'woocommerce',
  'setting-related_products_limit' => '3',
  'setting-product_description_type' => 'long',
  'setting-cart_show_seconds' => 'off',
  'setting-customizer_responsive_design_tablet_landscape' => '1024',
  'setting-customizer_responsive_design_tablet' => '768',
  'setting-customizer_responsive_design_mobile' => '680',
  'setting-mobile_menu_trigger_point' => '900',
  'setting-header_design' => 'header-horizontal',
  'setting-exclude_site_tagline' => 'on',
  'setting_search_form' => 'live_search',
  'setting-exclude_social_widget' => 'on',
  'setting-header_widgets' => 'headerwidget-3col',
  'setting-footer_design' => 'footer-horizontal-left',
  'setting-exclude_footer_site_logo' => 'on',
  'setting-use_float_back' => 'on',
  'setting-footer_widgets' => 'footerwidget-4col',
  'setting-footer_widget_position' => 'top',
  'setting-mega_menu_posts' => '5',
  'setting-mega_menu_image_width' => '180',
  'setting-mega_menu_image_height' => '120',
  'setting-mega_menu_post_count' => 'off',
  'setting-color_animation_speed' => '5',
  'setting-relationship_taxonomy' => 'category',
  'setting-relationship_taxonomy_entries' => '3',
  'setting-relationship_taxonomy_display_content' => 'none',
  'setting-single_slider_autoplay' => 'off',
  'setting-single_slider_speed' => 'normal',
  'setting-single_slider_effect' => 'slide',
  'setting-single_slider_height' => 'auto',
  'setting-more_posts' => 'infinite',
  'setting-entries_nav' => 'numbered',
  'setting-gallery_lightbox' => 'lightbox',
  'setting-img_php_base_size' => 'large',
  'setting-global_feature_size' => 'blank',
  'setting-link_icon_type' => 'font-icon',
  'setting-link_type_themify-link-0' => 'image-icon',
  'setting-link_title_themify-link-0' => 'Twitter',
  'setting-link_img_themify-link-0' => 'https://themify.me/demo/themes/ultra-gadgets/wp-content/themes/themify-ultra/themify/img/social/twitter.png',
  'setting-link_type_themify-link-1' => 'image-icon',
  'setting-link_title_themify-link-1' => 'Facebook',
  'setting-link_img_themify-link-1' => 'https://themify.me/demo/themes/ultra-gadgets/wp-content/themes/themify-ultra/themify/img/social/facebook.png',
  'setting-link_type_themify-link-2' => 'image-icon',
  'setting-link_title_themify-link-2' => 'YouTube',
  'setting-link_img_themify-link-2' => 'https://themify.me/demo/themes/ultra-gadgets/wp-content/themes/themify-ultra/themify/img/social/youtube.png',
  'setting-link_type_themify-link-3' => 'image-icon',
  'setting-link_title_themify-link-3' => 'Pinterest',
  'setting-link_img_themify-link-3' => 'https://themify.me/demo/themes/ultra-gadgets/wp-content/themes/themify-ultra/themify/img/social/pinterest.png',
  'setting-link_type_themify-link-4' => 'font-icon',
  'setting-link_title_themify-link-4' => 'Twitter',
  'setting-link_ficon_themify-link-4' => 'fa-twitter',
  'setting-link_type_themify-link-5' => 'font-icon',
  'setting-link_title_themify-link-5' => 'Facebook',
  'setting-link_ficon_themify-link-5' => 'fa-facebook',
  'setting-link_type_themify-link-6' => 'font-icon',
  'setting-link_title_themify-link-6' => 'YouTube',
  'setting-link_ficon_themify-link-6' => 'fa-youtube',
  'setting-link_type_themify-link-7' => 'font-icon',
  'setting-link_title_themify-link-7' => 'Pinterest',
  'setting-link_ficon_themify-link-7' => 'fa-pinterest',
  'setting-link_field_ids' => '{"themify-link-0":"themify-link-0","themify-link-1":"themify-link-1","themify-link-2":"themify-link-2","themify-link-3":"themify-link-3","themify-link-4":"themify-link-4","themify-link-5":"themify-link-5","themify-link-6":"themify-link-6","themify-link-7":"themify-link-7"}',
  'setting-link_field_hash' => '8',
  'setting-page_builder_is_active' => 'enable',
  'setting-page_builder_animation_appearance' => 'none',
  'setting-page_builder_animation_parallax_bg' => 'none',
  'setting-page_builder_animation_scroll_effect' => 'none',
  'setting-page_builder_animation_sticky_scroll' => 'none',
  'skin' => 'gadgets',
  'import_images' => 'on',
);
themify_set_data( $themify_data );
$theme = get_option( 'stylesheet' );
$theme_mods = array (
  0 => false,
  'custom_css_post_id' => -1,
);
update_option( "theme_mods_{$theme}", $theme_mods );
$menu_locations = array();
$menu = get_terms( "nav_menu", array( "slug" => "main-navigation" ) );
if( is_array( $menu ) && ! empty( $menu ) ) $menu_locations["main-nav"] = $menu[0]->term_id;
set_theme_mod( "nav_menu_locations", $menu_locations );



}
